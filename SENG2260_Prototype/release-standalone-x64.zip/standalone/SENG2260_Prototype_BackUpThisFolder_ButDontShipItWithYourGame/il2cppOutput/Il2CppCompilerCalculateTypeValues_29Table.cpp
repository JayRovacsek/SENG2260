﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"


// System.Char[]
struct CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2;
// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.Material>
struct Dictionary_2_tAD2222CCFCF5F2964C6F67732E9C8DAB764FE3AC;
// System.Collections.Generic.Dictionary`2<System.Type,System.Collections.Generic.KeyValuePair`2<UnityEngine.Rendering.CameraEvent,UnityEngine.Rendering.CommandBuffer>>
struct Dictionary_2_t3EA5986628F6FACCBE89BAE776057ACD38E26941;
// System.Collections.Generic.Dictionary`2<UnityEngine.PostProcessing.PostProcessingComponentBase,System.Boolean>
struct Dictionary_2_t8D598EF753E89FFF2347CC60824D3641B107B975;
// System.Collections.Generic.HashSet`1<UnityEngine.RenderTexture>
struct HashSet_1_t567782AF5635FCA485E6B51DD177FF52F96C80B0;
// System.Collections.Generic.List`1<UnityEngine.PostProcessing.PostProcessingComponentBase>
struct List_1_tDD5D4A93EE80EDC5A199B8CBB3810E0C1828747C;
// System.Func`2<UnityEngine.Vector2,UnityEngine.Matrix4x4>
struct Func_2_tA54608942A814FAFFEB1EDED9D6C2457F3A9CBE6;
// System.String
struct String_t;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// UnityEngine.AnimationCurve
struct AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C;
// UnityEngine.Camera
struct Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34;
// UnityEngine.Mesh
struct Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C;
// UnityEngine.PostProcessing.AmbientOcclusionComponent
struct AmbientOcclusionComponent_t81193D762EEB87BEFF67DB596A08B6930340BA8E;
// UnityEngine.PostProcessing.AmbientOcclusionModel
struct AmbientOcclusionModel_tA820D7E7EABB1F2E94CBA9C539B8BA45F36D6FF4;
// UnityEngine.PostProcessing.AntialiasingModel
struct AntialiasingModel_t816E25AD68EE2CE948F418317CB2FB664918438C;
// UnityEngine.PostProcessing.BloomComponent
struct BloomComponent_t7C69968D6D52293BB28214D29BF6DE4FE6DC431E;
// UnityEngine.PostProcessing.BloomModel
struct BloomModel_tE92443526105DCFC1CBCCC5693C46569B7C15FC3;
// UnityEngine.PostProcessing.BuiltinDebugViewsComponent
struct BuiltinDebugViewsComponent_t87723A30E7942CB092EAD35327CA11678261FF78;
// UnityEngine.PostProcessing.BuiltinDebugViewsModel
struct BuiltinDebugViewsModel_t3895BEF4E3FAA223414BEB50B52AE8E40209040D;
// UnityEngine.PostProcessing.ChromaticAberrationComponent
struct ChromaticAberrationComponent_tB1493E31E21AF2FBD5D5314EFE4E1E38680E8ACD;
// UnityEngine.PostProcessing.ChromaticAberrationModel
struct ChromaticAberrationModel_tC130D625088CD9AD6FC98DD5889D62FB32D26B9A;
// UnityEngine.PostProcessing.ColorGradingComponent
struct ColorGradingComponent_t3C9E6F9B43DCB041A15CD6439143D3732BBFF7DA;
// UnityEngine.PostProcessing.ColorGradingCurve
struct ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D;
// UnityEngine.PostProcessing.ColorGradingModel
struct ColorGradingModel_tA35650888B77D10DAB148BD56BB3CEC13C114F89;
// UnityEngine.PostProcessing.DepthOfFieldComponent
struct DepthOfFieldComponent_tE324DC55E88F64151539A068D089390FD90885F7;
// UnityEngine.PostProcessing.DepthOfFieldModel
struct DepthOfFieldModel_t467AC9D0D874371D108098B766B99177AE416A76;
// UnityEngine.PostProcessing.DitheringComponent
struct DitheringComponent_tD2CC455BCA16DB5143C280EEF5FCB135BFA9EF2F;
// UnityEngine.PostProcessing.DitheringModel
struct DitheringModel_t563302E6CCA426980051A9DD4BE43D907032077F;
// UnityEngine.PostProcessing.EyeAdaptationComponent
struct EyeAdaptationComponent_tBB4AB82FAD9CB6A10B01F41A73E35A2FB9B2FE88;
// UnityEngine.PostProcessing.EyeAdaptationModel
struct EyeAdaptationModel_t1ACCFD330F4AC0B18055B102CB33E568F6354255;
// UnityEngine.PostProcessing.FogComponent
struct FogComponent_t9842887E79FF485E76210221A8C71F64DF34C9D4;
// UnityEngine.PostProcessing.FogModel
struct FogModel_tCFF533017C35BAD8A878AC1912F1545DA5D1958B;
// UnityEngine.PostProcessing.FxaaComponent
struct FxaaComponent_t6192F903F2E99176AF962CBAB4D9A79102647F03;
// UnityEngine.PostProcessing.GrainComponent
struct GrainComponent_t860BB92FF09582F05AA7E0F5BA8C93D2D89CEF20;
// UnityEngine.PostProcessing.GrainModel
struct GrainModel_t9E9F9606895937388BD98DDBD0C12D33D820517A;
// UnityEngine.PostProcessing.MaterialFactory
struct MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05;
// UnityEngine.PostProcessing.MotionBlurComponent
struct MotionBlurComponent_t09EA322668565E8405B27EB4B8953068B27AA8AE;
// UnityEngine.PostProcessing.MotionBlurModel
struct MotionBlurModel_tF9261A288A5BDE37488E0D6F1EBF060FB528BCC3;
// UnityEngine.PostProcessing.PostProcessingContext
struct PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7;
// UnityEngine.PostProcessing.PostProcessingProfile
struct PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F;
// UnityEngine.PostProcessing.RenderTextureFactory
struct RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236;
// UnityEngine.PostProcessing.ScreenSpaceReflectionComponent
struct ScreenSpaceReflectionComponent_t785FC5967CACB503C8EFDBFF1C9D67710D9E43C8;
// UnityEngine.PostProcessing.ScreenSpaceReflectionModel
struct ScreenSpaceReflectionModel_t05FF878FC8651BE6F59BC62D0167970B047A0A82;
// UnityEngine.PostProcessing.TaaComponent
struct TaaComponent_t6C3D9F056CFBADD9316CFEA0105287F096F5BE65;
// UnityEngine.PostProcessing.UserLutComponent
struct UserLutComponent_t005DFBA977CDDBE18D9A45A9CD7BA3081F16FBFE;
// UnityEngine.PostProcessing.UserLutModel
struct UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3;
// UnityEngine.PostProcessing.VignetteComponent
struct VignetteComponent_t8DF40FEBD25DA993440BAE1B4306153A285834A1;
// UnityEngine.PostProcessing.VignetteModel
struct VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968;
// UnityEngine.RenderTexture
struct RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6;
// UnityEngine.Texture
struct Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4;
// UnityEngine.Texture2D
struct Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C;




#ifndef RUNTIMEOBJECT_H
#define RUNTIMEOBJECT_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Object

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RUNTIMEOBJECT_H
#ifndef VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#define VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.ValueType
struct  ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};
#endif // VALUETYPE_T4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_H
#ifndef COLORGRADINGCURVE_TBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D_H
#define COLORGRADINGCURVE_TBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ColorGradingCurve
struct  ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D  : public RuntimeObject
{
public:
	// UnityEngine.AnimationCurve UnityEngine.PostProcessing.ColorGradingCurve::curve
	AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * ___curve_0;
	// System.Boolean UnityEngine.PostProcessing.ColorGradingCurve::m_Loop
	bool ___m_Loop_1;
	// System.Single UnityEngine.PostProcessing.ColorGradingCurve::m_ZeroValue
	float ___m_ZeroValue_2;
	// System.Single UnityEngine.PostProcessing.ColorGradingCurve::m_Range
	float ___m_Range_3;
	// UnityEngine.AnimationCurve UnityEngine.PostProcessing.ColorGradingCurve::m_InternalLoopingCurve
	AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * ___m_InternalLoopingCurve_4;

public:
	inline static int32_t get_offset_of_curve_0() { return static_cast<int32_t>(offsetof(ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D, ___curve_0)); }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * get_curve_0() const { return ___curve_0; }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C ** get_address_of_curve_0() { return &___curve_0; }
	inline void set_curve_0(AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * value)
	{
		___curve_0 = value;
		Il2CppCodeGenWriteBarrier((&___curve_0), value);
	}

	inline static int32_t get_offset_of_m_Loop_1() { return static_cast<int32_t>(offsetof(ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D, ___m_Loop_1)); }
	inline bool get_m_Loop_1() const { return ___m_Loop_1; }
	inline bool* get_address_of_m_Loop_1() { return &___m_Loop_1; }
	inline void set_m_Loop_1(bool value)
	{
		___m_Loop_1 = value;
	}

	inline static int32_t get_offset_of_m_ZeroValue_2() { return static_cast<int32_t>(offsetof(ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D, ___m_ZeroValue_2)); }
	inline float get_m_ZeroValue_2() const { return ___m_ZeroValue_2; }
	inline float* get_address_of_m_ZeroValue_2() { return &___m_ZeroValue_2; }
	inline void set_m_ZeroValue_2(float value)
	{
		___m_ZeroValue_2 = value;
	}

	inline static int32_t get_offset_of_m_Range_3() { return static_cast<int32_t>(offsetof(ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D, ___m_Range_3)); }
	inline float get_m_Range_3() const { return ___m_Range_3; }
	inline float* get_address_of_m_Range_3() { return &___m_Range_3; }
	inline void set_m_Range_3(float value)
	{
		___m_Range_3 = value;
	}

	inline static int32_t get_offset_of_m_InternalLoopingCurve_4() { return static_cast<int32_t>(offsetof(ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D, ___m_InternalLoopingCurve_4)); }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * get_m_InternalLoopingCurve_4() const { return ___m_InternalLoopingCurve_4; }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C ** get_address_of_m_InternalLoopingCurve_4() { return &___m_InternalLoopingCurve_4; }
	inline void set_m_InternalLoopingCurve_4(AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * value)
	{
		___m_InternalLoopingCurve_4 = value;
		Il2CppCodeGenWriteBarrier((&___m_InternalLoopingCurve_4), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLORGRADINGCURVE_TBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D_H
#ifndef GRAPHICSUTILS_T158EBC195D948DBB2232E769FCC62C706A60F464_H
#define GRAPHICSUTILS_T158EBC195D948DBB2232E769FCC62C706A60F464_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.GraphicsUtils
struct  GraphicsUtils_t158EBC195D948DBB2232E769FCC62C706A60F464  : public RuntimeObject
{
public:

public:
};

struct GraphicsUtils_t158EBC195D948DBB2232E769FCC62C706A60F464_StaticFields
{
public:
	// UnityEngine.Texture2D UnityEngine.PostProcessing.GraphicsUtils::s_WhiteTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___s_WhiteTexture_0;
	// UnityEngine.Mesh UnityEngine.PostProcessing.GraphicsUtils::s_Quad
	Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * ___s_Quad_1;

public:
	inline static int32_t get_offset_of_s_WhiteTexture_0() { return static_cast<int32_t>(offsetof(GraphicsUtils_t158EBC195D948DBB2232E769FCC62C706A60F464_StaticFields, ___s_WhiteTexture_0)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_s_WhiteTexture_0() const { return ___s_WhiteTexture_0; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_s_WhiteTexture_0() { return &___s_WhiteTexture_0; }
	inline void set_s_WhiteTexture_0(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___s_WhiteTexture_0 = value;
		Il2CppCodeGenWriteBarrier((&___s_WhiteTexture_0), value);
	}

	inline static int32_t get_offset_of_s_Quad_1() { return static_cast<int32_t>(offsetof(GraphicsUtils_t158EBC195D948DBB2232E769FCC62C706A60F464_StaticFields, ___s_Quad_1)); }
	inline Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * get_s_Quad_1() const { return ___s_Quad_1; }
	inline Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C ** get_address_of_s_Quad_1() { return &___s_Quad_1; }
	inline void set_s_Quad_1(Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * value)
	{
		___s_Quad_1 = value;
		Il2CppCodeGenWriteBarrier((&___s_Quad_1), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GRAPHICSUTILS_T158EBC195D948DBB2232E769FCC62C706A60F464_H
#ifndef MATERIALFACTORY_TBEC3A9AE4401BDF1E5645C87895C3BC097638F05_H
#define MATERIALFACTORY_TBEC3A9AE4401BDF1E5645C87895C3BC097638F05_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.MaterialFactory
struct  MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05  : public RuntimeObject
{
public:
	// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.Material> UnityEngine.PostProcessing.MaterialFactory::m_Materials
	Dictionary_2_tAD2222CCFCF5F2964C6F67732E9C8DAB764FE3AC * ___m_Materials_0;

public:
	inline static int32_t get_offset_of_m_Materials_0() { return static_cast<int32_t>(offsetof(MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05, ___m_Materials_0)); }
	inline Dictionary_2_tAD2222CCFCF5F2964C6F67732E9C8DAB764FE3AC * get_m_Materials_0() const { return ___m_Materials_0; }
	inline Dictionary_2_tAD2222CCFCF5F2964C6F67732E9C8DAB764FE3AC ** get_address_of_m_Materials_0() { return &___m_Materials_0; }
	inline void set_m_Materials_0(Dictionary_2_tAD2222CCFCF5F2964C6F67732E9C8DAB764FE3AC * value)
	{
		___m_Materials_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_Materials_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MATERIALFACTORY_TBEC3A9AE4401BDF1E5645C87895C3BC097638F05_H
#ifndef POSTPROCESSINGCOMPONENTBASE_TC8BC68DB18D717E17089935C74F230467E0BC942_H
#define POSTPROCESSINGCOMPONENTBASE_TC8BC68DB18D717E17089935C74F230467E0BC942_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.PostProcessingComponentBase
struct  PostProcessingComponentBase_tC8BC68DB18D717E17089935C74F230467E0BC942  : public RuntimeObject
{
public:
	// UnityEngine.PostProcessing.PostProcessingContext UnityEngine.PostProcessing.PostProcessingComponentBase::context
	PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * ___context_0;

public:
	inline static int32_t get_offset_of_context_0() { return static_cast<int32_t>(offsetof(PostProcessingComponentBase_tC8BC68DB18D717E17089935C74F230467E0BC942, ___context_0)); }
	inline PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * get_context_0() const { return ___context_0; }
	inline PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 ** get_address_of_context_0() { return &___context_0; }
	inline void set_context_0(PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * value)
	{
		___context_0 = value;
		Il2CppCodeGenWriteBarrier((&___context_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSINGCOMPONENTBASE_TC8BC68DB18D717E17089935C74F230467E0BC942_H
#ifndef POSTPROCESSINGCONTEXT_TD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7_H
#define POSTPROCESSINGCONTEXT_TD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.PostProcessingContext
struct  PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7  : public RuntimeObject
{
public:
	// UnityEngine.PostProcessing.PostProcessingProfile UnityEngine.PostProcessing.PostProcessingContext::profile
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F * ___profile_0;
	// UnityEngine.Camera UnityEngine.PostProcessing.PostProcessingContext::camera
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___camera_1;
	// UnityEngine.PostProcessing.MaterialFactory UnityEngine.PostProcessing.PostProcessingContext::materialFactory
	MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05 * ___materialFactory_2;
	// UnityEngine.PostProcessing.RenderTextureFactory UnityEngine.PostProcessing.PostProcessingContext::renderTextureFactory
	RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236 * ___renderTextureFactory_3;
	// System.Boolean UnityEngine.PostProcessing.PostProcessingContext::<interrupted>k__BackingField
	bool ___U3CinterruptedU3Ek__BackingField_4;

public:
	inline static int32_t get_offset_of_profile_0() { return static_cast<int32_t>(offsetof(PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7, ___profile_0)); }
	inline PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F * get_profile_0() const { return ___profile_0; }
	inline PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F ** get_address_of_profile_0() { return &___profile_0; }
	inline void set_profile_0(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F * value)
	{
		___profile_0 = value;
		Il2CppCodeGenWriteBarrier((&___profile_0), value);
	}

	inline static int32_t get_offset_of_camera_1() { return static_cast<int32_t>(offsetof(PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7, ___camera_1)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_camera_1() const { return ___camera_1; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_camera_1() { return &___camera_1; }
	inline void set_camera_1(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___camera_1 = value;
		Il2CppCodeGenWriteBarrier((&___camera_1), value);
	}

	inline static int32_t get_offset_of_materialFactory_2() { return static_cast<int32_t>(offsetof(PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7, ___materialFactory_2)); }
	inline MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05 * get_materialFactory_2() const { return ___materialFactory_2; }
	inline MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05 ** get_address_of_materialFactory_2() { return &___materialFactory_2; }
	inline void set_materialFactory_2(MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05 * value)
	{
		___materialFactory_2 = value;
		Il2CppCodeGenWriteBarrier((&___materialFactory_2), value);
	}

	inline static int32_t get_offset_of_renderTextureFactory_3() { return static_cast<int32_t>(offsetof(PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7, ___renderTextureFactory_3)); }
	inline RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236 * get_renderTextureFactory_3() const { return ___renderTextureFactory_3; }
	inline RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236 ** get_address_of_renderTextureFactory_3() { return &___renderTextureFactory_3; }
	inline void set_renderTextureFactory_3(RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236 * value)
	{
		___renderTextureFactory_3 = value;
		Il2CppCodeGenWriteBarrier((&___renderTextureFactory_3), value);
	}

	inline static int32_t get_offset_of_U3CinterruptedU3Ek__BackingField_4() { return static_cast<int32_t>(offsetof(PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7, ___U3CinterruptedU3Ek__BackingField_4)); }
	inline bool get_U3CinterruptedU3Ek__BackingField_4() const { return ___U3CinterruptedU3Ek__BackingField_4; }
	inline bool* get_address_of_U3CinterruptedU3Ek__BackingField_4() { return &___U3CinterruptedU3Ek__BackingField_4; }
	inline void set_U3CinterruptedU3Ek__BackingField_4(bool value)
	{
		___U3CinterruptedU3Ek__BackingField_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSINGCONTEXT_TD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7_H
#ifndef POSTPROCESSINGMODEL_TC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A_H
#define POSTPROCESSINGMODEL_TC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.PostProcessingModel
struct  PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A  : public RuntimeObject
{
public:
	// System.Boolean UnityEngine.PostProcessing.PostProcessingModel::m_Enabled
	bool ___m_Enabled_0;

public:
	inline static int32_t get_offset_of_m_Enabled_0() { return static_cast<int32_t>(offsetof(PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A, ___m_Enabled_0)); }
	inline bool get_m_Enabled_0() const { return ___m_Enabled_0; }
	inline bool* get_address_of_m_Enabled_0() { return &___m_Enabled_0; }
	inline void set_m_Enabled_0(bool value)
	{
		___m_Enabled_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSINGMODEL_TC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A_H
#ifndef RENDERTEXTUREFACTORY_T522EDCAD4499B0594A69BCB40DB5698647DDB236_H
#define RENDERTEXTUREFACTORY_T522EDCAD4499B0594A69BCB40DB5698647DDB236_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.RenderTextureFactory
struct  RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236  : public RuntimeObject
{
public:
	// System.Collections.Generic.HashSet`1<UnityEngine.RenderTexture> UnityEngine.PostProcessing.RenderTextureFactory::m_TemporaryRTs
	HashSet_1_t567782AF5635FCA485E6B51DD177FF52F96C80B0 * ___m_TemporaryRTs_0;

public:
	inline static int32_t get_offset_of_m_TemporaryRTs_0() { return static_cast<int32_t>(offsetof(RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236, ___m_TemporaryRTs_0)); }
	inline HashSet_1_t567782AF5635FCA485E6B51DD177FF52F96C80B0 * get_m_TemporaryRTs_0() const { return ___m_TemporaryRTs_0; }
	inline HashSet_1_t567782AF5635FCA485E6B51DD177FF52F96C80B0 ** get_address_of_m_TemporaryRTs_0() { return &___m_TemporaryRTs_0; }
	inline void set_m_TemporaryRTs_0(HashSet_1_t567782AF5635FCA485E6B51DD177FF52F96C80B0 * value)
	{
		___m_TemporaryRTs_0 = value;
		Il2CppCodeGenWriteBarrier((&___m_TemporaryRTs_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // RENDERTEXTUREFACTORY_T522EDCAD4499B0594A69BCB40DB5698647DDB236_H
#ifndef __STATICARRAYINITTYPESIZEU3D12_T65235398342E0C6C387633EE4B2E7F326A539C91_H
#define __STATICARRAYINITTYPESIZEU3D12_T65235398342E0C6C387633EE4B2E7F326A539C91_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12
struct  __StaticArrayInitTypeSizeU3D12_t65235398342E0C6C387633EE4B2E7F326A539C91 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D12_t65235398342E0C6C387633EE4B2E7F326A539C91__padding[12];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // __STATICARRAYINITTYPESIZEU3D12_T65235398342E0C6C387633EE4B2E7F326A539C91_H
#ifndef __STATICARRAYINITTYPESIZEU3D24_T0186834C621050282F5EF637E836A6E1DC934A34_H
#define __STATICARRAYINITTYPESIZEU3D24_T0186834C621050282F5EF637E836A6E1DC934A34_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24
struct  __StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34__padding[24];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // __STATICARRAYINITTYPESIZEU3D24_T0186834C621050282F5EF637E836A6E1DC934A34_H
#ifndef ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#define ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.Enum
struct  Enum_t2AF27C02B8653AE29442467390005ABC74D8F521  : public ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF
{
public:

public:
};

struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((&___enumSeperatorCharArray_0), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_com
{
};
#endif // ENUM_T2AF27C02B8653AE29442467390005ABC74D8F521_H
#ifndef INTPTR_T_H
#define INTPTR_T_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// System.IntPtr
struct  IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTPTR_T_H
#ifndef COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#define COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Color
struct  Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 
{
public:
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;

public:
	inline static int32_t get_offset_of_r_0() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___r_0)); }
	inline float get_r_0() const { return ___r_0; }
	inline float* get_address_of_r_0() { return &___r_0; }
	inline void set_r_0(float value)
	{
		___r_0 = value;
	}

	inline static int32_t get_offset_of_g_1() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___g_1)); }
	inline float get_g_1() const { return ___g_1; }
	inline float* get_address_of_g_1() { return &___g_1; }
	inline void set_g_1(float value)
	{
		___g_1 = value;
	}

	inline static int32_t get_offset_of_b_2() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___b_2)); }
	inline float get_b_2() const { return ___b_2; }
	inline float* get_address_of_b_2() { return &___b_2; }
	inline void set_b_2(float value)
	{
		___b_2 = value;
	}

	inline static int32_t get_offset_of_a_3() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___a_3)); }
	inline float get_a_3() const { return ___a_3; }
	inline float* get_address_of_a_3() { return &___a_3; }
	inline void set_a_3(float value)
	{
		___a_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLOR_T119BCA590009762C7223FDD3AF9706653AC84ED2_H
#ifndef BLOOMSETTINGS_T404181973007E2892BF7D816A9BFABA899AEF4D0_H
#define BLOOMSETTINGS_T404181973007E2892BF7D816A9BFABA899AEF4D0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.BloomModel/BloomSettings
struct  BloomSettings_t404181973007E2892BF7D816A9BFABA899AEF4D0 
{
public:
	// System.Single UnityEngine.PostProcessing.BloomModel/BloomSettings::intensity
	float ___intensity_0;
	// System.Single UnityEngine.PostProcessing.BloomModel/BloomSettings::threshold
	float ___threshold_1;
	// System.Single UnityEngine.PostProcessing.BloomModel/BloomSettings::softKnee
	float ___softKnee_2;
	// System.Single UnityEngine.PostProcessing.BloomModel/BloomSettings::radius
	float ___radius_3;
	// System.Boolean UnityEngine.PostProcessing.BloomModel/BloomSettings::antiFlicker
	bool ___antiFlicker_4;

public:
	inline static int32_t get_offset_of_intensity_0() { return static_cast<int32_t>(offsetof(BloomSettings_t404181973007E2892BF7D816A9BFABA899AEF4D0, ___intensity_0)); }
	inline float get_intensity_0() const { return ___intensity_0; }
	inline float* get_address_of_intensity_0() { return &___intensity_0; }
	inline void set_intensity_0(float value)
	{
		___intensity_0 = value;
	}

	inline static int32_t get_offset_of_threshold_1() { return static_cast<int32_t>(offsetof(BloomSettings_t404181973007E2892BF7D816A9BFABA899AEF4D0, ___threshold_1)); }
	inline float get_threshold_1() const { return ___threshold_1; }
	inline float* get_address_of_threshold_1() { return &___threshold_1; }
	inline void set_threshold_1(float value)
	{
		___threshold_1 = value;
	}

	inline static int32_t get_offset_of_softKnee_2() { return static_cast<int32_t>(offsetof(BloomSettings_t404181973007E2892BF7D816A9BFABA899AEF4D0, ___softKnee_2)); }
	inline float get_softKnee_2() const { return ___softKnee_2; }
	inline float* get_address_of_softKnee_2() { return &___softKnee_2; }
	inline void set_softKnee_2(float value)
	{
		___softKnee_2 = value;
	}

	inline static int32_t get_offset_of_radius_3() { return static_cast<int32_t>(offsetof(BloomSettings_t404181973007E2892BF7D816A9BFABA899AEF4D0, ___radius_3)); }
	inline float get_radius_3() const { return ___radius_3; }
	inline float* get_address_of_radius_3() { return &___radius_3; }
	inline void set_radius_3(float value)
	{
		___radius_3 = value;
	}

	inline static int32_t get_offset_of_antiFlicker_4() { return static_cast<int32_t>(offsetof(BloomSettings_t404181973007E2892BF7D816A9BFABA899AEF4D0, ___antiFlicker_4)); }
	inline bool get_antiFlicker_4() const { return ___antiFlicker_4; }
	inline bool* get_address_of_antiFlicker_4() { return &___antiFlicker_4; }
	inline void set_antiFlicker_4(bool value)
	{
		___antiFlicker_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.BloomModel/BloomSettings
struct BloomSettings_t404181973007E2892BF7D816A9BFABA899AEF4D0_marshaled_pinvoke
{
	float ___intensity_0;
	float ___threshold_1;
	float ___softKnee_2;
	float ___radius_3;
	int32_t ___antiFlicker_4;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.BloomModel/BloomSettings
struct BloomSettings_t404181973007E2892BF7D816A9BFABA899AEF4D0_marshaled_com
{
	float ___intensity_0;
	float ___threshold_1;
	float ___softKnee_2;
	float ___radius_3;
	int32_t ___antiFlicker_4;
};
#endif // BLOOMSETTINGS_T404181973007E2892BF7D816A9BFABA899AEF4D0_H
#ifndef LENSDIRTSETTINGS_T853B5863231B63C1DDAA5F98E04699597E47137A_H
#define LENSDIRTSETTINGS_T853B5863231B63C1DDAA5F98E04699597E47137A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.BloomModel/LensDirtSettings
struct  LensDirtSettings_t853B5863231B63C1DDAA5F98E04699597E47137A 
{
public:
	// UnityEngine.Texture UnityEngine.PostProcessing.BloomModel/LensDirtSettings::texture
	Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___texture_0;
	// System.Single UnityEngine.PostProcessing.BloomModel/LensDirtSettings::intensity
	float ___intensity_1;

public:
	inline static int32_t get_offset_of_texture_0() { return static_cast<int32_t>(offsetof(LensDirtSettings_t853B5863231B63C1DDAA5F98E04699597E47137A, ___texture_0)); }
	inline Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * get_texture_0() const { return ___texture_0; }
	inline Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 ** get_address_of_texture_0() { return &___texture_0; }
	inline void set_texture_0(Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * value)
	{
		___texture_0 = value;
		Il2CppCodeGenWriteBarrier((&___texture_0), value);
	}

	inline static int32_t get_offset_of_intensity_1() { return static_cast<int32_t>(offsetof(LensDirtSettings_t853B5863231B63C1DDAA5F98E04699597E47137A, ___intensity_1)); }
	inline float get_intensity_1() const { return ___intensity_1; }
	inline float* get_address_of_intensity_1() { return &___intensity_1; }
	inline void set_intensity_1(float value)
	{
		___intensity_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.BloomModel/LensDirtSettings
struct LensDirtSettings_t853B5863231B63C1DDAA5F98E04699597E47137A_marshaled_pinvoke
{
	Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___texture_0;
	float ___intensity_1;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.BloomModel/LensDirtSettings
struct LensDirtSettings_t853B5863231B63C1DDAA5F98E04699597E47137A_marshaled_com
{
	Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___texture_0;
	float ___intensity_1;
};
#endif // LENSDIRTSETTINGS_T853B5863231B63C1DDAA5F98E04699597E47137A_H
#ifndef DEPTHSETTINGS_TC484EB6F5B3327CF16840634323AF5CFFEE126EC_H
#define DEPTHSETTINGS_TC484EB6F5B3327CF16840634323AF5CFFEE126EC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.BuiltinDebugViewsModel/DepthSettings
struct  DepthSettings_tC484EB6F5B3327CF16840634323AF5CFFEE126EC 
{
public:
	// System.Single UnityEngine.PostProcessing.BuiltinDebugViewsModel/DepthSettings::scale
	float ___scale_0;

public:
	inline static int32_t get_offset_of_scale_0() { return static_cast<int32_t>(offsetof(DepthSettings_tC484EB6F5B3327CF16840634323AF5CFFEE126EC, ___scale_0)); }
	inline float get_scale_0() const { return ___scale_0; }
	inline float* get_address_of_scale_0() { return &___scale_0; }
	inline void set_scale_0(float value)
	{
		___scale_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEPTHSETTINGS_TC484EB6F5B3327CF16840634323AF5CFFEE126EC_H
#ifndef MOTIONVECTORSSETTINGS_T52E092FE390993B7C5006300306ED2C3F942B256_H
#define MOTIONVECTORSSETTINGS_T52E092FE390993B7C5006300306ED2C3F942B256_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.BuiltinDebugViewsModel/MotionVectorsSettings
struct  MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256 
{
public:
	// System.Single UnityEngine.PostProcessing.BuiltinDebugViewsModel/MotionVectorsSettings::sourceOpacity
	float ___sourceOpacity_0;
	// System.Single UnityEngine.PostProcessing.BuiltinDebugViewsModel/MotionVectorsSettings::motionImageOpacity
	float ___motionImageOpacity_1;
	// System.Single UnityEngine.PostProcessing.BuiltinDebugViewsModel/MotionVectorsSettings::motionImageAmplitude
	float ___motionImageAmplitude_2;
	// System.Single UnityEngine.PostProcessing.BuiltinDebugViewsModel/MotionVectorsSettings::motionVectorsOpacity
	float ___motionVectorsOpacity_3;
	// System.Int32 UnityEngine.PostProcessing.BuiltinDebugViewsModel/MotionVectorsSettings::motionVectorsResolution
	int32_t ___motionVectorsResolution_4;
	// System.Single UnityEngine.PostProcessing.BuiltinDebugViewsModel/MotionVectorsSettings::motionVectorsAmplitude
	float ___motionVectorsAmplitude_5;

public:
	inline static int32_t get_offset_of_sourceOpacity_0() { return static_cast<int32_t>(offsetof(MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256, ___sourceOpacity_0)); }
	inline float get_sourceOpacity_0() const { return ___sourceOpacity_0; }
	inline float* get_address_of_sourceOpacity_0() { return &___sourceOpacity_0; }
	inline void set_sourceOpacity_0(float value)
	{
		___sourceOpacity_0 = value;
	}

	inline static int32_t get_offset_of_motionImageOpacity_1() { return static_cast<int32_t>(offsetof(MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256, ___motionImageOpacity_1)); }
	inline float get_motionImageOpacity_1() const { return ___motionImageOpacity_1; }
	inline float* get_address_of_motionImageOpacity_1() { return &___motionImageOpacity_1; }
	inline void set_motionImageOpacity_1(float value)
	{
		___motionImageOpacity_1 = value;
	}

	inline static int32_t get_offset_of_motionImageAmplitude_2() { return static_cast<int32_t>(offsetof(MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256, ___motionImageAmplitude_2)); }
	inline float get_motionImageAmplitude_2() const { return ___motionImageAmplitude_2; }
	inline float* get_address_of_motionImageAmplitude_2() { return &___motionImageAmplitude_2; }
	inline void set_motionImageAmplitude_2(float value)
	{
		___motionImageAmplitude_2 = value;
	}

	inline static int32_t get_offset_of_motionVectorsOpacity_3() { return static_cast<int32_t>(offsetof(MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256, ___motionVectorsOpacity_3)); }
	inline float get_motionVectorsOpacity_3() const { return ___motionVectorsOpacity_3; }
	inline float* get_address_of_motionVectorsOpacity_3() { return &___motionVectorsOpacity_3; }
	inline void set_motionVectorsOpacity_3(float value)
	{
		___motionVectorsOpacity_3 = value;
	}

	inline static int32_t get_offset_of_motionVectorsResolution_4() { return static_cast<int32_t>(offsetof(MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256, ___motionVectorsResolution_4)); }
	inline int32_t get_motionVectorsResolution_4() const { return ___motionVectorsResolution_4; }
	inline int32_t* get_address_of_motionVectorsResolution_4() { return &___motionVectorsResolution_4; }
	inline void set_motionVectorsResolution_4(int32_t value)
	{
		___motionVectorsResolution_4 = value;
	}

	inline static int32_t get_offset_of_motionVectorsAmplitude_5() { return static_cast<int32_t>(offsetof(MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256, ___motionVectorsAmplitude_5)); }
	inline float get_motionVectorsAmplitude_5() const { return ___motionVectorsAmplitude_5; }
	inline float* get_address_of_motionVectorsAmplitude_5() { return &___motionVectorsAmplitude_5; }
	inline void set_motionVectorsAmplitude_5(float value)
	{
		___motionVectorsAmplitude_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MOTIONVECTORSSETTINGS_T52E092FE390993B7C5006300306ED2C3F942B256_H
#ifndef SETTINGS_T3B36530BC44129694D3A136E05855736FAB00743_H
#define SETTINGS_T3B36530BC44129694D3A136E05855736FAB00743_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ChromaticAberrationModel/Settings
struct  Settings_t3B36530BC44129694D3A136E05855736FAB00743 
{
public:
	// UnityEngine.Texture2D UnityEngine.PostProcessing.ChromaticAberrationModel/Settings::spectralTexture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___spectralTexture_0;
	// System.Single UnityEngine.PostProcessing.ChromaticAberrationModel/Settings::intensity
	float ___intensity_1;

public:
	inline static int32_t get_offset_of_spectralTexture_0() { return static_cast<int32_t>(offsetof(Settings_t3B36530BC44129694D3A136E05855736FAB00743, ___spectralTexture_0)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_spectralTexture_0() const { return ___spectralTexture_0; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_spectralTexture_0() { return &___spectralTexture_0; }
	inline void set_spectralTexture_0(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___spectralTexture_0 = value;
		Il2CppCodeGenWriteBarrier((&___spectralTexture_0), value);
	}

	inline static int32_t get_offset_of_intensity_1() { return static_cast<int32_t>(offsetof(Settings_t3B36530BC44129694D3A136E05855736FAB00743, ___intensity_1)); }
	inline float get_intensity_1() const { return ___intensity_1; }
	inline float* get_address_of_intensity_1() { return &___intensity_1; }
	inline void set_intensity_1(float value)
	{
		___intensity_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.ChromaticAberrationModel/Settings
struct Settings_t3B36530BC44129694D3A136E05855736FAB00743_marshaled_pinvoke
{
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___spectralTexture_0;
	float ___intensity_1;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.ChromaticAberrationModel/Settings
struct Settings_t3B36530BC44129694D3A136E05855736FAB00743_marshaled_com
{
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___spectralTexture_0;
	float ___intensity_1;
};
#endif // SETTINGS_T3B36530BC44129694D3A136E05855736FAB00743_H
#ifndef BASICSETTINGS_T6BDB17237FE91CFD75E4659392E068376014EA49_H
#define BASICSETTINGS_T6BDB17237FE91CFD75E4659392E068376014EA49_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ColorGradingModel/BasicSettings
struct  BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49 
{
public:
	// System.Single UnityEngine.PostProcessing.ColorGradingModel/BasicSettings::postExposure
	float ___postExposure_0;
	// System.Single UnityEngine.PostProcessing.ColorGradingModel/BasicSettings::temperature
	float ___temperature_1;
	// System.Single UnityEngine.PostProcessing.ColorGradingModel/BasicSettings::tint
	float ___tint_2;
	// System.Single UnityEngine.PostProcessing.ColorGradingModel/BasicSettings::hueShift
	float ___hueShift_3;
	// System.Single UnityEngine.PostProcessing.ColorGradingModel/BasicSettings::saturation
	float ___saturation_4;
	// System.Single UnityEngine.PostProcessing.ColorGradingModel/BasicSettings::contrast
	float ___contrast_5;

public:
	inline static int32_t get_offset_of_postExposure_0() { return static_cast<int32_t>(offsetof(BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49, ___postExposure_0)); }
	inline float get_postExposure_0() const { return ___postExposure_0; }
	inline float* get_address_of_postExposure_0() { return &___postExposure_0; }
	inline void set_postExposure_0(float value)
	{
		___postExposure_0 = value;
	}

	inline static int32_t get_offset_of_temperature_1() { return static_cast<int32_t>(offsetof(BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49, ___temperature_1)); }
	inline float get_temperature_1() const { return ___temperature_1; }
	inline float* get_address_of_temperature_1() { return &___temperature_1; }
	inline void set_temperature_1(float value)
	{
		___temperature_1 = value;
	}

	inline static int32_t get_offset_of_tint_2() { return static_cast<int32_t>(offsetof(BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49, ___tint_2)); }
	inline float get_tint_2() const { return ___tint_2; }
	inline float* get_address_of_tint_2() { return &___tint_2; }
	inline void set_tint_2(float value)
	{
		___tint_2 = value;
	}

	inline static int32_t get_offset_of_hueShift_3() { return static_cast<int32_t>(offsetof(BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49, ___hueShift_3)); }
	inline float get_hueShift_3() const { return ___hueShift_3; }
	inline float* get_address_of_hueShift_3() { return &___hueShift_3; }
	inline void set_hueShift_3(float value)
	{
		___hueShift_3 = value;
	}

	inline static int32_t get_offset_of_saturation_4() { return static_cast<int32_t>(offsetof(BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49, ___saturation_4)); }
	inline float get_saturation_4() const { return ___saturation_4; }
	inline float* get_address_of_saturation_4() { return &___saturation_4; }
	inline void set_saturation_4(float value)
	{
		___saturation_4 = value;
	}

	inline static int32_t get_offset_of_contrast_5() { return static_cast<int32_t>(offsetof(BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49, ___contrast_5)); }
	inline float get_contrast_5() const { return ___contrast_5; }
	inline float* get_address_of_contrast_5() { return &___contrast_5; }
	inline void set_contrast_5(float value)
	{
		___contrast_5 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BASICSETTINGS_T6BDB17237FE91CFD75E4659392E068376014EA49_H
#ifndef CURVESSETTINGS_T1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E_H
#define CURVESSETTINGS_T1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings
struct  CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E 
{
public:
	// UnityEngine.PostProcessing.ColorGradingCurve UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings::master
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___master_0;
	// UnityEngine.PostProcessing.ColorGradingCurve UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings::red
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___red_1;
	// UnityEngine.PostProcessing.ColorGradingCurve UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings::green
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___green_2;
	// UnityEngine.PostProcessing.ColorGradingCurve UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings::blue
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___blue_3;
	// UnityEngine.PostProcessing.ColorGradingCurve UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings::hueVShue
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___hueVShue_4;
	// UnityEngine.PostProcessing.ColorGradingCurve UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings::hueVSsat
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___hueVSsat_5;
	// UnityEngine.PostProcessing.ColorGradingCurve UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings::satVSsat
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___satVSsat_6;
	// UnityEngine.PostProcessing.ColorGradingCurve UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings::lumVSsat
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___lumVSsat_7;
	// System.Int32 UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings::e_CurrentEditingCurve
	int32_t ___e_CurrentEditingCurve_8;
	// System.Boolean UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings::e_CurveY
	bool ___e_CurveY_9;
	// System.Boolean UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings::e_CurveR
	bool ___e_CurveR_10;
	// System.Boolean UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings::e_CurveG
	bool ___e_CurveG_11;
	// System.Boolean UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings::e_CurveB
	bool ___e_CurveB_12;

public:
	inline static int32_t get_offset_of_master_0() { return static_cast<int32_t>(offsetof(CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E, ___master_0)); }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * get_master_0() const { return ___master_0; }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D ** get_address_of_master_0() { return &___master_0; }
	inline void set_master_0(ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * value)
	{
		___master_0 = value;
		Il2CppCodeGenWriteBarrier((&___master_0), value);
	}

	inline static int32_t get_offset_of_red_1() { return static_cast<int32_t>(offsetof(CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E, ___red_1)); }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * get_red_1() const { return ___red_1; }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D ** get_address_of_red_1() { return &___red_1; }
	inline void set_red_1(ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * value)
	{
		___red_1 = value;
		Il2CppCodeGenWriteBarrier((&___red_1), value);
	}

	inline static int32_t get_offset_of_green_2() { return static_cast<int32_t>(offsetof(CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E, ___green_2)); }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * get_green_2() const { return ___green_2; }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D ** get_address_of_green_2() { return &___green_2; }
	inline void set_green_2(ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * value)
	{
		___green_2 = value;
		Il2CppCodeGenWriteBarrier((&___green_2), value);
	}

	inline static int32_t get_offset_of_blue_3() { return static_cast<int32_t>(offsetof(CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E, ___blue_3)); }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * get_blue_3() const { return ___blue_3; }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D ** get_address_of_blue_3() { return &___blue_3; }
	inline void set_blue_3(ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * value)
	{
		___blue_3 = value;
		Il2CppCodeGenWriteBarrier((&___blue_3), value);
	}

	inline static int32_t get_offset_of_hueVShue_4() { return static_cast<int32_t>(offsetof(CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E, ___hueVShue_4)); }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * get_hueVShue_4() const { return ___hueVShue_4; }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D ** get_address_of_hueVShue_4() { return &___hueVShue_4; }
	inline void set_hueVShue_4(ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * value)
	{
		___hueVShue_4 = value;
		Il2CppCodeGenWriteBarrier((&___hueVShue_4), value);
	}

	inline static int32_t get_offset_of_hueVSsat_5() { return static_cast<int32_t>(offsetof(CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E, ___hueVSsat_5)); }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * get_hueVSsat_5() const { return ___hueVSsat_5; }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D ** get_address_of_hueVSsat_5() { return &___hueVSsat_5; }
	inline void set_hueVSsat_5(ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * value)
	{
		___hueVSsat_5 = value;
		Il2CppCodeGenWriteBarrier((&___hueVSsat_5), value);
	}

	inline static int32_t get_offset_of_satVSsat_6() { return static_cast<int32_t>(offsetof(CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E, ___satVSsat_6)); }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * get_satVSsat_6() const { return ___satVSsat_6; }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D ** get_address_of_satVSsat_6() { return &___satVSsat_6; }
	inline void set_satVSsat_6(ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * value)
	{
		___satVSsat_6 = value;
		Il2CppCodeGenWriteBarrier((&___satVSsat_6), value);
	}

	inline static int32_t get_offset_of_lumVSsat_7() { return static_cast<int32_t>(offsetof(CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E, ___lumVSsat_7)); }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * get_lumVSsat_7() const { return ___lumVSsat_7; }
	inline ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D ** get_address_of_lumVSsat_7() { return &___lumVSsat_7; }
	inline void set_lumVSsat_7(ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * value)
	{
		___lumVSsat_7 = value;
		Il2CppCodeGenWriteBarrier((&___lumVSsat_7), value);
	}

	inline static int32_t get_offset_of_e_CurrentEditingCurve_8() { return static_cast<int32_t>(offsetof(CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E, ___e_CurrentEditingCurve_8)); }
	inline int32_t get_e_CurrentEditingCurve_8() const { return ___e_CurrentEditingCurve_8; }
	inline int32_t* get_address_of_e_CurrentEditingCurve_8() { return &___e_CurrentEditingCurve_8; }
	inline void set_e_CurrentEditingCurve_8(int32_t value)
	{
		___e_CurrentEditingCurve_8 = value;
	}

	inline static int32_t get_offset_of_e_CurveY_9() { return static_cast<int32_t>(offsetof(CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E, ___e_CurveY_9)); }
	inline bool get_e_CurveY_9() const { return ___e_CurveY_9; }
	inline bool* get_address_of_e_CurveY_9() { return &___e_CurveY_9; }
	inline void set_e_CurveY_9(bool value)
	{
		___e_CurveY_9 = value;
	}

	inline static int32_t get_offset_of_e_CurveR_10() { return static_cast<int32_t>(offsetof(CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E, ___e_CurveR_10)); }
	inline bool get_e_CurveR_10() const { return ___e_CurveR_10; }
	inline bool* get_address_of_e_CurveR_10() { return &___e_CurveR_10; }
	inline void set_e_CurveR_10(bool value)
	{
		___e_CurveR_10 = value;
	}

	inline static int32_t get_offset_of_e_CurveG_11() { return static_cast<int32_t>(offsetof(CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E, ___e_CurveG_11)); }
	inline bool get_e_CurveG_11() const { return ___e_CurveG_11; }
	inline bool* get_address_of_e_CurveG_11() { return &___e_CurveG_11; }
	inline void set_e_CurveG_11(bool value)
	{
		___e_CurveG_11 = value;
	}

	inline static int32_t get_offset_of_e_CurveB_12() { return static_cast<int32_t>(offsetof(CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E, ___e_CurveB_12)); }
	inline bool get_e_CurveB_12() const { return ___e_CurveB_12; }
	inline bool* get_address_of_e_CurveB_12() { return &___e_CurveB_12; }
	inline void set_e_CurveB_12(bool value)
	{
		___e_CurveB_12 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings
struct CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E_marshaled_pinvoke
{
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___master_0;
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___red_1;
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___green_2;
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___blue_3;
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___hueVShue_4;
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___hueVSsat_5;
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___satVSsat_6;
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___lumVSsat_7;
	int32_t ___e_CurrentEditingCurve_8;
	int32_t ___e_CurveY_9;
	int32_t ___e_CurveR_10;
	int32_t ___e_CurveG_11;
	int32_t ___e_CurveB_12;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings
struct CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E_marshaled_com
{
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___master_0;
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___red_1;
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___green_2;
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___blue_3;
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___hueVShue_4;
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___hueVSsat_5;
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___satVSsat_6;
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D * ___lumVSsat_7;
	int32_t ___e_CurrentEditingCurve_8;
	int32_t ___e_CurveY_9;
	int32_t ___e_CurveR_10;
	int32_t ___e_CurveG_11;
	int32_t ___e_CurveB_12;
};
#endif // CURVESSETTINGS_T1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E_H
#ifndef SETTINGS_TC9C0AEE3013633FFCEA5FDFD2D15E71EB7251724_H
#define SETTINGS_TC9C0AEE3013633FFCEA5FDFD2D15E71EB7251724_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.DitheringModel/Settings
struct  Settings_tC9C0AEE3013633FFCEA5FDFD2D15E71EB7251724 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Settings_tC9C0AEE3013633FFCEA5FDFD2D15E71EB7251724__padding[1];
	};

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SETTINGS_TC9C0AEE3013633FFCEA5FDFD2D15E71EB7251724_H
#ifndef SETTINGS_TA824AD6B5D555CEB742A622222775333124B2107_H
#define SETTINGS_TA824AD6B5D555CEB742A622222775333124B2107_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.FogModel/Settings
struct  Settings_tA824AD6B5D555CEB742A622222775333124B2107 
{
public:
	// System.Boolean UnityEngine.PostProcessing.FogModel/Settings::excludeSkybox
	bool ___excludeSkybox_0;

public:
	inline static int32_t get_offset_of_excludeSkybox_0() { return static_cast<int32_t>(offsetof(Settings_tA824AD6B5D555CEB742A622222775333124B2107, ___excludeSkybox_0)); }
	inline bool get_excludeSkybox_0() const { return ___excludeSkybox_0; }
	inline bool* get_address_of_excludeSkybox_0() { return &___excludeSkybox_0; }
	inline void set_excludeSkybox_0(bool value)
	{
		___excludeSkybox_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.FogModel/Settings
struct Settings_tA824AD6B5D555CEB742A622222775333124B2107_marshaled_pinvoke
{
	int32_t ___excludeSkybox_0;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.FogModel/Settings
struct Settings_tA824AD6B5D555CEB742A622222775333124B2107_marshaled_com
{
	int32_t ___excludeSkybox_0;
};
#endif // SETTINGS_TA824AD6B5D555CEB742A622222775333124B2107_H
#ifndef SETTINGS_TCFBBF182482600D1B65A7B66A6B980BDE79A4D6F_H
#define SETTINGS_TCFBBF182482600D1B65A7B66A6B980BDE79A4D6F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.GrainModel/Settings
struct  Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F 
{
public:
	// System.Boolean UnityEngine.PostProcessing.GrainModel/Settings::colored
	bool ___colored_0;
	// System.Single UnityEngine.PostProcessing.GrainModel/Settings::intensity
	float ___intensity_1;
	// System.Single UnityEngine.PostProcessing.GrainModel/Settings::size
	float ___size_2;
	// System.Single UnityEngine.PostProcessing.GrainModel/Settings::luminanceContribution
	float ___luminanceContribution_3;

public:
	inline static int32_t get_offset_of_colored_0() { return static_cast<int32_t>(offsetof(Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F, ___colored_0)); }
	inline bool get_colored_0() const { return ___colored_0; }
	inline bool* get_address_of_colored_0() { return &___colored_0; }
	inline void set_colored_0(bool value)
	{
		___colored_0 = value;
	}

	inline static int32_t get_offset_of_intensity_1() { return static_cast<int32_t>(offsetof(Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F, ___intensity_1)); }
	inline float get_intensity_1() const { return ___intensity_1; }
	inline float* get_address_of_intensity_1() { return &___intensity_1; }
	inline void set_intensity_1(float value)
	{
		___intensity_1 = value;
	}

	inline static int32_t get_offset_of_size_2() { return static_cast<int32_t>(offsetof(Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F, ___size_2)); }
	inline float get_size_2() const { return ___size_2; }
	inline float* get_address_of_size_2() { return &___size_2; }
	inline void set_size_2(float value)
	{
		___size_2 = value;
	}

	inline static int32_t get_offset_of_luminanceContribution_3() { return static_cast<int32_t>(offsetof(Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F, ___luminanceContribution_3)); }
	inline float get_luminanceContribution_3() const { return ___luminanceContribution_3; }
	inline float* get_address_of_luminanceContribution_3() { return &___luminanceContribution_3; }
	inline void set_luminanceContribution_3(float value)
	{
		___luminanceContribution_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.GrainModel/Settings
struct Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F_marshaled_pinvoke
{
	int32_t ___colored_0;
	float ___intensity_1;
	float ___size_2;
	float ___luminanceContribution_3;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.GrainModel/Settings
struct Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F_marshaled_com
{
	int32_t ___colored_0;
	float ___intensity_1;
	float ___size_2;
	float ___luminanceContribution_3;
};
#endif // SETTINGS_TCFBBF182482600D1B65A7B66A6B980BDE79A4D6F_H
#ifndef SETTINGS_T6272550371AE697276AC2B9E97B10C20531B4A02_H
#define SETTINGS_T6272550371AE697276AC2B9E97B10C20531B4A02_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.MotionBlurModel/Settings
struct  Settings_t6272550371AE697276AC2B9E97B10C20531B4A02 
{
public:
	// System.Single UnityEngine.PostProcessing.MotionBlurModel/Settings::shutterAngle
	float ___shutterAngle_0;
	// System.Int32 UnityEngine.PostProcessing.MotionBlurModel/Settings::sampleCount
	int32_t ___sampleCount_1;
	// System.Single UnityEngine.PostProcessing.MotionBlurModel/Settings::frameBlending
	float ___frameBlending_2;

public:
	inline static int32_t get_offset_of_shutterAngle_0() { return static_cast<int32_t>(offsetof(Settings_t6272550371AE697276AC2B9E97B10C20531B4A02, ___shutterAngle_0)); }
	inline float get_shutterAngle_0() const { return ___shutterAngle_0; }
	inline float* get_address_of_shutterAngle_0() { return &___shutterAngle_0; }
	inline void set_shutterAngle_0(float value)
	{
		___shutterAngle_0 = value;
	}

	inline static int32_t get_offset_of_sampleCount_1() { return static_cast<int32_t>(offsetof(Settings_t6272550371AE697276AC2B9E97B10C20531B4A02, ___sampleCount_1)); }
	inline int32_t get_sampleCount_1() const { return ___sampleCount_1; }
	inline int32_t* get_address_of_sampleCount_1() { return &___sampleCount_1; }
	inline void set_sampleCount_1(int32_t value)
	{
		___sampleCount_1 = value;
	}

	inline static int32_t get_offset_of_frameBlending_2() { return static_cast<int32_t>(offsetof(Settings_t6272550371AE697276AC2B9E97B10C20531B4A02, ___frameBlending_2)); }
	inline float get_frameBlending_2() const { return ___frameBlending_2; }
	inline float* get_address_of_frameBlending_2() { return &___frameBlending_2; }
	inline void set_frameBlending_2(float value)
	{
		___frameBlending_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SETTINGS_T6272550371AE697276AC2B9E97B10C20531B4A02_H
#ifndef INTENSITYSETTINGS_TBF0EB1716740BB43A3A2E99806F9BC18D65DB087_H
#define INTENSITYSETTINGS_TBF0EB1716740BB43A3A2E99806F9BC18D65DB087_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ScreenSpaceReflectionModel/IntensitySettings
struct  IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087 
{
public:
	// System.Single UnityEngine.PostProcessing.ScreenSpaceReflectionModel/IntensitySettings::reflectionMultiplier
	float ___reflectionMultiplier_0;
	// System.Single UnityEngine.PostProcessing.ScreenSpaceReflectionModel/IntensitySettings::fadeDistance
	float ___fadeDistance_1;
	// System.Single UnityEngine.PostProcessing.ScreenSpaceReflectionModel/IntensitySettings::fresnelFade
	float ___fresnelFade_2;
	// System.Single UnityEngine.PostProcessing.ScreenSpaceReflectionModel/IntensitySettings::fresnelFadePower
	float ___fresnelFadePower_3;

public:
	inline static int32_t get_offset_of_reflectionMultiplier_0() { return static_cast<int32_t>(offsetof(IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087, ___reflectionMultiplier_0)); }
	inline float get_reflectionMultiplier_0() const { return ___reflectionMultiplier_0; }
	inline float* get_address_of_reflectionMultiplier_0() { return &___reflectionMultiplier_0; }
	inline void set_reflectionMultiplier_0(float value)
	{
		___reflectionMultiplier_0 = value;
	}

	inline static int32_t get_offset_of_fadeDistance_1() { return static_cast<int32_t>(offsetof(IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087, ___fadeDistance_1)); }
	inline float get_fadeDistance_1() const { return ___fadeDistance_1; }
	inline float* get_address_of_fadeDistance_1() { return &___fadeDistance_1; }
	inline void set_fadeDistance_1(float value)
	{
		___fadeDistance_1 = value;
	}

	inline static int32_t get_offset_of_fresnelFade_2() { return static_cast<int32_t>(offsetof(IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087, ___fresnelFade_2)); }
	inline float get_fresnelFade_2() const { return ___fresnelFade_2; }
	inline float* get_address_of_fresnelFade_2() { return &___fresnelFade_2; }
	inline void set_fresnelFade_2(float value)
	{
		___fresnelFade_2 = value;
	}

	inline static int32_t get_offset_of_fresnelFadePower_3() { return static_cast<int32_t>(offsetof(IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087, ___fresnelFadePower_3)); }
	inline float get_fresnelFadePower_3() const { return ___fresnelFadePower_3; }
	inline float* get_address_of_fresnelFadePower_3() { return &___fresnelFadePower_3; }
	inline void set_fresnelFadePower_3(float value)
	{
		___fresnelFadePower_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // INTENSITYSETTINGS_TBF0EB1716740BB43A3A2E99806F9BC18D65DB087_H
#ifndef SCREENEDGEMASK_T94FB1CC384B7C414838A714400DF33EE0F26C468_H
#define SCREENEDGEMASK_T94FB1CC384B7C414838A714400DF33EE0F26C468_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ScreenEdgeMask
struct  ScreenEdgeMask_t94FB1CC384B7C414838A714400DF33EE0F26C468 
{
public:
	// System.Single UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ScreenEdgeMask::intensity
	float ___intensity_0;

public:
	inline static int32_t get_offset_of_intensity_0() { return static_cast<int32_t>(offsetof(ScreenEdgeMask_t94FB1CC384B7C414838A714400DF33EE0F26C468, ___intensity_0)); }
	inline float get_intensity_0() const { return ___intensity_0; }
	inline float* get_address_of_intensity_0() { return &___intensity_0; }
	inline void set_intensity_0(float value)
	{
		___intensity_0 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SCREENEDGEMASK_T94FB1CC384B7C414838A714400DF33EE0F26C468_H
#ifndef SETTINGS_T89579C94217BC0734AF7DE292787FC983E2B4313_H
#define SETTINGS_T89579C94217BC0734AF7DE292787FC983E2B4313_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.UserLutModel/Settings
struct  Settings_t89579C94217BC0734AF7DE292787FC983E2B4313 
{
public:
	// UnityEngine.Texture2D UnityEngine.PostProcessing.UserLutModel/Settings::lut
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___lut_0;
	// System.Single UnityEngine.PostProcessing.UserLutModel/Settings::contribution
	float ___contribution_1;

public:
	inline static int32_t get_offset_of_lut_0() { return static_cast<int32_t>(offsetof(Settings_t89579C94217BC0734AF7DE292787FC983E2B4313, ___lut_0)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_lut_0() const { return ___lut_0; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_lut_0() { return &___lut_0; }
	inline void set_lut_0(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___lut_0 = value;
		Il2CppCodeGenWriteBarrier((&___lut_0), value);
	}

	inline static int32_t get_offset_of_contribution_1() { return static_cast<int32_t>(offsetof(Settings_t89579C94217BC0734AF7DE292787FC983E2B4313, ___contribution_1)); }
	inline float get_contribution_1() const { return ___contribution_1; }
	inline float* get_address_of_contribution_1() { return &___contribution_1; }
	inline void set_contribution_1(float value)
	{
		___contribution_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.UserLutModel/Settings
struct Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshaled_pinvoke
{
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___lut_0;
	float ___contribution_1;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.UserLutModel/Settings
struct Settings_t89579C94217BC0734AF7DE292787FC983E2B4313_marshaled_com
{
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___lut_0;
	float ___contribution_1;
};
#endif // SETTINGS_T89579C94217BC0734AF7DE292787FC983E2B4313_H
#ifndef VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#define VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector2
struct  Vector2_tA85D2DD88578276CA8A8796756458277E72D073D 
{
public:
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}
};

struct Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields
{
public:
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___negativeInfinityVector_9;

public:
	inline static int32_t get_offset_of_zeroVector_2() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___zeroVector_2)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_zeroVector_2() const { return ___zeroVector_2; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_zeroVector_2() { return &___zeroVector_2; }
	inline void set_zeroVector_2(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___zeroVector_2 = value;
	}

	inline static int32_t get_offset_of_oneVector_3() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___oneVector_3)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_oneVector_3() const { return ___oneVector_3; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_oneVector_3() { return &___oneVector_3; }
	inline void set_oneVector_3(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___oneVector_3 = value;
	}

	inline static int32_t get_offset_of_upVector_4() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___upVector_4)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_upVector_4() const { return ___upVector_4; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_upVector_4() { return &___upVector_4; }
	inline void set_upVector_4(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___upVector_4 = value;
	}

	inline static int32_t get_offset_of_downVector_5() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___downVector_5)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_downVector_5() const { return ___downVector_5; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_downVector_5() { return &___downVector_5; }
	inline void set_downVector_5(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___downVector_5 = value;
	}

	inline static int32_t get_offset_of_leftVector_6() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___leftVector_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_leftVector_6() const { return ___leftVector_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_leftVector_6() { return &___leftVector_6; }
	inline void set_leftVector_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___leftVector_6 = value;
	}

	inline static int32_t get_offset_of_rightVector_7() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___rightVector_7)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_rightVector_7() const { return ___rightVector_7; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_rightVector_7() { return &___rightVector_7; }
	inline void set_rightVector_7(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___rightVector_7 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___positiveInfinityVector_8)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_positiveInfinityVector_8() const { return ___positiveInfinityVector_8; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_positiveInfinityVector_8() { return &___positiveInfinityVector_8; }
	inline void set_positiveInfinityVector_8(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___positiveInfinityVector_8 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_9() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___negativeInfinityVector_9)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_negativeInfinityVector_9() const { return ___negativeInfinityVector_9; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_negativeInfinityVector_9() { return &___negativeInfinityVector_9; }
	inline void set_negativeInfinityVector_9(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___negativeInfinityVector_9 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR2_TA85D2DD88578276CA8A8796756458277E72D073D_H
#ifndef VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#define VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Vector3
struct  Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;

public:
	inline static int32_t get_offset_of_x_2() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___x_2)); }
	inline float get_x_2() const { return ___x_2; }
	inline float* get_address_of_x_2() { return &___x_2; }
	inline void set_x_2(float value)
	{
		___x_2 = value;
	}

	inline static int32_t get_offset_of_y_3() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___y_3)); }
	inline float get_y_3() const { return ___y_3; }
	inline float* get_address_of_y_3() { return &___y_3; }
	inline void set_y_3(float value)
	{
		___y_3 = value;
	}

	inline static int32_t get_offset_of_z_4() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___z_4)); }
	inline float get_z_4() const { return ___z_4; }
	inline float* get_address_of_z_4() { return &___z_4; }
	inline void set_z_4(float value)
	{
		___z_4 = value;
	}
};

struct Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___negativeInfinityVector_14;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___zeroVector_5)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___oneVector_6)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_upVector_7() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___upVector_7)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_upVector_7() const { return ___upVector_7; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_upVector_7() { return &___upVector_7; }
	inline void set_upVector_7(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___upVector_7 = value;
	}

	inline static int32_t get_offset_of_downVector_8() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___downVector_8)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_downVector_8() const { return ___downVector_8; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_downVector_8() { return &___downVector_8; }
	inline void set_downVector_8(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___downVector_8 = value;
	}

	inline static int32_t get_offset_of_leftVector_9() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___leftVector_9)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_leftVector_9() const { return ___leftVector_9; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_leftVector_9() { return &___leftVector_9; }
	inline void set_leftVector_9(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___leftVector_9 = value;
	}

	inline static int32_t get_offset_of_rightVector_10() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___rightVector_10)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_rightVector_10() const { return ___rightVector_10; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_rightVector_10() { return &___rightVector_10; }
	inline void set_rightVector_10(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___rightVector_10 = value;
	}

	inline static int32_t get_offset_of_forwardVector_11() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___forwardVector_11)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_forwardVector_11() const { return ___forwardVector_11; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_forwardVector_11() { return &___forwardVector_11; }
	inline void set_forwardVector_11(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___forwardVector_11 = value;
	}

	inline static int32_t get_offset_of_backVector_12() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___backVector_12)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_backVector_12() const { return ___backVector_12; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_backVector_12() { return &___backVector_12; }
	inline void set_backVector_12(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___backVector_12 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___positiveInfinityVector_13)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_positiveInfinityVector_13() const { return ___positiveInfinityVector_13; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_positiveInfinityVector_13() { return &___positiveInfinityVector_13; }
	inline void set_positiveInfinityVector_13(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___positiveInfinityVector_13 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_14() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___negativeInfinityVector_14)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_negativeInfinityVector_14() const { return ___negativeInfinityVector_14; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_negativeInfinityVector_14() { return &___negativeInfinityVector_14; }
	inline void set_negativeInfinityVector_14(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___negativeInfinityVector_14 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VECTOR3_TDCF05E21F632FE2BA260C06E0D10CA81513E6720_H
#ifndef U3CPRIVATEIMPLEMENTATIONDETAILSU3E_T4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_H
#define U3CPRIVATEIMPLEMENTATIONDETAILSU3E_T4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <PrivateImplementationDetails>
struct  U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A  : public RuntimeObject
{
public:

public:
};

struct U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_StaticFields
{
public:
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=12 <PrivateImplementationDetails>::51A7A390CD6DE245186881400B18C9D822EFE240
	__StaticArrayInitTypeSizeU3D12_t65235398342E0C6C387633EE4B2E7F326A539C91  ___51A7A390CD6DE245186881400B18C9D822EFE240_0;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::C90F38A020811481753795774EB5AF353F414C59
	__StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34  ___C90F38A020811481753795774EB5AF353F414C59_1;

public:
	inline static int32_t get_offset_of_U351A7A390CD6DE245186881400B18C9D822EFE240_0() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_StaticFields, ___51A7A390CD6DE245186881400B18C9D822EFE240_0)); }
	inline __StaticArrayInitTypeSizeU3D12_t65235398342E0C6C387633EE4B2E7F326A539C91  get_U351A7A390CD6DE245186881400B18C9D822EFE240_0() const { return ___51A7A390CD6DE245186881400B18C9D822EFE240_0; }
	inline __StaticArrayInitTypeSizeU3D12_t65235398342E0C6C387633EE4B2E7F326A539C91 * get_address_of_U351A7A390CD6DE245186881400B18C9D822EFE240_0() { return &___51A7A390CD6DE245186881400B18C9D822EFE240_0; }
	inline void set_U351A7A390CD6DE245186881400B18C9D822EFE240_0(__StaticArrayInitTypeSizeU3D12_t65235398342E0C6C387633EE4B2E7F326A539C91  value)
	{
		___51A7A390CD6DE245186881400B18C9D822EFE240_0 = value;
	}

	inline static int32_t get_offset_of_C90F38A020811481753795774EB5AF353F414C59_1() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_StaticFields, ___C90F38A020811481753795774EB5AF353F414C59_1)); }
	inline __StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34  get_C90F38A020811481753795774EB5AF353F414C59_1() const { return ___C90F38A020811481753795774EB5AF353F414C59_1; }
	inline __StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34 * get_address_of_C90F38A020811481753795774EB5AF353F414C59_1() { return &___C90F38A020811481753795774EB5AF353F414C59_1; }
	inline void set_C90F38A020811481753795774EB5AF353F414C59_1(__StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34  value)
	{
		___C90F38A020811481753795774EB5AF353F414C59_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // U3CPRIVATEIMPLEMENTATIONDETAILSU3E_T4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_H
#ifndef OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#define OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Object
struct  Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};
#endif // OBJECT_TAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_H
#ifndef SETTINGS_TDAF4DB4C944143B285B5CBAF40509B6559800E3A_H
#define SETTINGS_TDAF4DB4C944143B285B5CBAF40509B6559800E3A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.BloomModel/Settings
struct  Settings_tDAF4DB4C944143B285B5CBAF40509B6559800E3A 
{
public:
	// UnityEngine.PostProcessing.BloomModel/BloomSettings UnityEngine.PostProcessing.BloomModel/Settings::bloom
	BloomSettings_t404181973007E2892BF7D816A9BFABA899AEF4D0  ___bloom_0;
	// UnityEngine.PostProcessing.BloomModel/LensDirtSettings UnityEngine.PostProcessing.BloomModel/Settings::lensDirt
	LensDirtSettings_t853B5863231B63C1DDAA5F98E04699597E47137A  ___lensDirt_1;

public:
	inline static int32_t get_offset_of_bloom_0() { return static_cast<int32_t>(offsetof(Settings_tDAF4DB4C944143B285B5CBAF40509B6559800E3A, ___bloom_0)); }
	inline BloomSettings_t404181973007E2892BF7D816A9BFABA899AEF4D0  get_bloom_0() const { return ___bloom_0; }
	inline BloomSettings_t404181973007E2892BF7D816A9BFABA899AEF4D0 * get_address_of_bloom_0() { return &___bloom_0; }
	inline void set_bloom_0(BloomSettings_t404181973007E2892BF7D816A9BFABA899AEF4D0  value)
	{
		___bloom_0 = value;
	}

	inline static int32_t get_offset_of_lensDirt_1() { return static_cast<int32_t>(offsetof(Settings_tDAF4DB4C944143B285B5CBAF40509B6559800E3A, ___lensDirt_1)); }
	inline LensDirtSettings_t853B5863231B63C1DDAA5F98E04699597E47137A  get_lensDirt_1() const { return ___lensDirt_1; }
	inline LensDirtSettings_t853B5863231B63C1DDAA5F98E04699597E47137A * get_address_of_lensDirt_1() { return &___lensDirt_1; }
	inline void set_lensDirt_1(LensDirtSettings_t853B5863231B63C1DDAA5F98E04699597E47137A  value)
	{
		___lensDirt_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.BloomModel/Settings
struct Settings_tDAF4DB4C944143B285B5CBAF40509B6559800E3A_marshaled_pinvoke
{
	BloomSettings_t404181973007E2892BF7D816A9BFABA899AEF4D0_marshaled_pinvoke ___bloom_0;
	LensDirtSettings_t853B5863231B63C1DDAA5F98E04699597E47137A_marshaled_pinvoke ___lensDirt_1;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.BloomModel/Settings
struct Settings_tDAF4DB4C944143B285B5CBAF40509B6559800E3A_marshaled_com
{
	BloomSettings_t404181973007E2892BF7D816A9BFABA899AEF4D0_marshaled_com ___bloom_0;
	LensDirtSettings_t853B5863231B63C1DDAA5F98E04699597E47137A_marshaled_com ___lensDirt_1;
};
#endif // SETTINGS_TDAF4DB4C944143B285B5CBAF40509B6559800E3A_H
#ifndef MODE_TE6D4BA29442A4ABB76D9ADE04877164873931AB7_H
#define MODE_TE6D4BA29442A4ABB76D9ADE04877164873931AB7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.BuiltinDebugViewsModel/Mode
struct  Mode_tE6D4BA29442A4ABB76D9ADE04877164873931AB7 
{
public:
	// System.Int32 UnityEngine.PostProcessing.BuiltinDebugViewsModel/Mode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Mode_tE6D4BA29442A4ABB76D9ADE04877164873931AB7, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MODE_TE6D4BA29442A4ABB76D9ADE04877164873931AB7_H
#ifndef CHROMATICABERRATIONMODEL_TC130D625088CD9AD6FC98DD5889D62FB32D26B9A_H
#define CHROMATICABERRATIONMODEL_TC130D625088CD9AD6FC98DD5889D62FB32D26B9A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ChromaticAberrationModel
struct  ChromaticAberrationModel_tC130D625088CD9AD6FC98DD5889D62FB32D26B9A  : public PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A
{
public:
	// UnityEngine.PostProcessing.ChromaticAberrationModel/Settings UnityEngine.PostProcessing.ChromaticAberrationModel::m_Settings
	Settings_t3B36530BC44129694D3A136E05855736FAB00743  ___m_Settings_1;

public:
	inline static int32_t get_offset_of_m_Settings_1() { return static_cast<int32_t>(offsetof(ChromaticAberrationModel_tC130D625088CD9AD6FC98DD5889D62FB32D26B9A, ___m_Settings_1)); }
	inline Settings_t3B36530BC44129694D3A136E05855736FAB00743  get_m_Settings_1() const { return ___m_Settings_1; }
	inline Settings_t3B36530BC44129694D3A136E05855736FAB00743 * get_address_of_m_Settings_1() { return &___m_Settings_1; }
	inline void set_m_Settings_1(Settings_t3B36530BC44129694D3A136E05855736FAB00743  value)
	{
		___m_Settings_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CHROMATICABERRATIONMODEL_TC130D625088CD9AD6FC98DD5889D62FB32D26B9A_H
#ifndef CHANNELMIXERSETTINGS_T431B35AD1976F2AF867DD00D992769BE455DC09B_H
#define CHANNELMIXERSETTINGS_T431B35AD1976F2AF867DD00D992769BE455DC09B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ColorGradingModel/ChannelMixerSettings
struct  ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B 
{
public:
	// UnityEngine.Vector3 UnityEngine.PostProcessing.ColorGradingModel/ChannelMixerSettings::red
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___red_0;
	// UnityEngine.Vector3 UnityEngine.PostProcessing.ColorGradingModel/ChannelMixerSettings::green
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___green_1;
	// UnityEngine.Vector3 UnityEngine.PostProcessing.ColorGradingModel/ChannelMixerSettings::blue
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___blue_2;
	// System.Int32 UnityEngine.PostProcessing.ColorGradingModel/ChannelMixerSettings::currentEditingChannel
	int32_t ___currentEditingChannel_3;

public:
	inline static int32_t get_offset_of_red_0() { return static_cast<int32_t>(offsetof(ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B, ___red_0)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_red_0() const { return ___red_0; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_red_0() { return &___red_0; }
	inline void set_red_0(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___red_0 = value;
	}

	inline static int32_t get_offset_of_green_1() { return static_cast<int32_t>(offsetof(ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B, ___green_1)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_green_1() const { return ___green_1; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_green_1() { return &___green_1; }
	inline void set_green_1(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___green_1 = value;
	}

	inline static int32_t get_offset_of_blue_2() { return static_cast<int32_t>(offsetof(ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B, ___blue_2)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_blue_2() const { return ___blue_2; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_blue_2() { return &___blue_2; }
	inline void set_blue_2(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___blue_2 = value;
	}

	inline static int32_t get_offset_of_currentEditingChannel_3() { return static_cast<int32_t>(offsetof(ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B, ___currentEditingChannel_3)); }
	inline int32_t get_currentEditingChannel_3() const { return ___currentEditingChannel_3; }
	inline int32_t* get_address_of_currentEditingChannel_3() { return &___currentEditingChannel_3; }
	inline void set_currentEditingChannel_3(int32_t value)
	{
		___currentEditingChannel_3 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // CHANNELMIXERSETTINGS_T431B35AD1976F2AF867DD00D992769BE455DC09B_H
#ifndef COLORWHEELMODE_TF684466A07AFC545A3148235696DDAFE737CE34E_H
#define COLORWHEELMODE_TF684466A07AFC545A3148235696DDAFE737CE34E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ColorGradingModel/ColorWheelMode
struct  ColorWheelMode_tF684466A07AFC545A3148235696DDAFE737CE34E 
{
public:
	// System.Int32 UnityEngine.PostProcessing.ColorGradingModel/ColorWheelMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ColorWheelMode_tF684466A07AFC545A3148235696DDAFE737CE34E, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLORWHEELMODE_TF684466A07AFC545A3148235696DDAFE737CE34E_H
#ifndef LINEARWHEELSSETTINGS_TA2E68F6BF46B81203AF36DCB129409CAB51EC704_H
#define LINEARWHEELSSETTINGS_TA2E68F6BF46B81203AF36DCB129409CAB51EC704_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ColorGradingModel/LinearWheelsSettings
struct  LinearWheelsSettings_tA2E68F6BF46B81203AF36DCB129409CAB51EC704 
{
public:
	// UnityEngine.Color UnityEngine.PostProcessing.ColorGradingModel/LinearWheelsSettings::lift
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___lift_0;
	// UnityEngine.Color UnityEngine.PostProcessing.ColorGradingModel/LinearWheelsSettings::gamma
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___gamma_1;
	// UnityEngine.Color UnityEngine.PostProcessing.ColorGradingModel/LinearWheelsSettings::gain
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___gain_2;

public:
	inline static int32_t get_offset_of_lift_0() { return static_cast<int32_t>(offsetof(LinearWheelsSettings_tA2E68F6BF46B81203AF36DCB129409CAB51EC704, ___lift_0)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_lift_0() const { return ___lift_0; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_lift_0() { return &___lift_0; }
	inline void set_lift_0(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___lift_0 = value;
	}

	inline static int32_t get_offset_of_gamma_1() { return static_cast<int32_t>(offsetof(LinearWheelsSettings_tA2E68F6BF46B81203AF36DCB129409CAB51EC704, ___gamma_1)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_gamma_1() const { return ___gamma_1; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_gamma_1() { return &___gamma_1; }
	inline void set_gamma_1(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___gamma_1 = value;
	}

	inline static int32_t get_offset_of_gain_2() { return static_cast<int32_t>(offsetof(LinearWheelsSettings_tA2E68F6BF46B81203AF36DCB129409CAB51EC704, ___gain_2)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_gain_2() const { return ___gain_2; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_gain_2() { return &___gain_2; }
	inline void set_gain_2(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___gain_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LINEARWHEELSSETTINGS_TA2E68F6BF46B81203AF36DCB129409CAB51EC704_H
#ifndef LOGWHEELSSETTINGS_T6946B0985F2ECDA5D31B31D9DC70072ED0819EF5_H
#define LOGWHEELSSETTINGS_T6946B0985F2ECDA5D31B31D9DC70072ED0819EF5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ColorGradingModel/LogWheelsSettings
struct  LogWheelsSettings_t6946B0985F2ECDA5D31B31D9DC70072ED0819EF5 
{
public:
	// UnityEngine.Color UnityEngine.PostProcessing.ColorGradingModel/LogWheelsSettings::slope
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___slope_0;
	// UnityEngine.Color UnityEngine.PostProcessing.ColorGradingModel/LogWheelsSettings::power
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___power_1;
	// UnityEngine.Color UnityEngine.PostProcessing.ColorGradingModel/LogWheelsSettings::offset
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___offset_2;

public:
	inline static int32_t get_offset_of_slope_0() { return static_cast<int32_t>(offsetof(LogWheelsSettings_t6946B0985F2ECDA5D31B31D9DC70072ED0819EF5, ___slope_0)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_slope_0() const { return ___slope_0; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_slope_0() { return &___slope_0; }
	inline void set_slope_0(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___slope_0 = value;
	}

	inline static int32_t get_offset_of_power_1() { return static_cast<int32_t>(offsetof(LogWheelsSettings_t6946B0985F2ECDA5D31B31D9DC70072ED0819EF5, ___power_1)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_power_1() const { return ___power_1; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_power_1() { return &___power_1; }
	inline void set_power_1(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___power_1 = value;
	}

	inline static int32_t get_offset_of_offset_2() { return static_cast<int32_t>(offsetof(LogWheelsSettings_t6946B0985F2ECDA5D31B31D9DC70072ED0819EF5, ___offset_2)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_offset_2() const { return ___offset_2; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_offset_2() { return &___offset_2; }
	inline void set_offset_2(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___offset_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // LOGWHEELSSETTINGS_T6946B0985F2ECDA5D31B31D9DC70072ED0819EF5_H
#ifndef TONEMAPPER_TB393B8D6ED90C74BC74C860CEE8B3D2374DEE621_H
#define TONEMAPPER_TB393B8D6ED90C74BC74C860CEE8B3D2374DEE621_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ColorGradingModel/Tonemapper
struct  Tonemapper_tB393B8D6ED90C74BC74C860CEE8B3D2374DEE621 
{
public:
	// System.Int32 UnityEngine.PostProcessing.ColorGradingModel/Tonemapper::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Tonemapper_tB393B8D6ED90C74BC74C860CEE8B3D2374DEE621, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TONEMAPPER_TB393B8D6ED90C74BC74C860CEE8B3D2374DEE621_H
#ifndef KERNELSIZE_TE92DFA32991EA99967B6FA6A9CA00BC6002B72AD_H
#define KERNELSIZE_TE92DFA32991EA99967B6FA6A9CA00BC6002B72AD_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.DepthOfFieldModel/KernelSize
struct  KernelSize_tE92DFA32991EA99967B6FA6A9CA00BC6002B72AD 
{
public:
	// System.Int32 UnityEngine.PostProcessing.DepthOfFieldModel/KernelSize::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(KernelSize_tE92DFA32991EA99967B6FA6A9CA00BC6002B72AD, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // KERNELSIZE_TE92DFA32991EA99967B6FA6A9CA00BC6002B72AD_H
#ifndef DITHERINGMODEL_T563302E6CCA426980051A9DD4BE43D907032077F_H
#define DITHERINGMODEL_T563302E6CCA426980051A9DD4BE43D907032077F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.DitheringModel
struct  DitheringModel_t563302E6CCA426980051A9DD4BE43D907032077F  : public PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A
{
public:
	// UnityEngine.PostProcessing.DitheringModel/Settings UnityEngine.PostProcessing.DitheringModel::m_Settings
	Settings_tC9C0AEE3013633FFCEA5FDFD2D15E71EB7251724  ___m_Settings_1;

public:
	inline static int32_t get_offset_of_m_Settings_1() { return static_cast<int32_t>(offsetof(DitheringModel_t563302E6CCA426980051A9DD4BE43D907032077F, ___m_Settings_1)); }
	inline Settings_tC9C0AEE3013633FFCEA5FDFD2D15E71EB7251724  get_m_Settings_1() const { return ___m_Settings_1; }
	inline Settings_tC9C0AEE3013633FFCEA5FDFD2D15E71EB7251724 * get_address_of_m_Settings_1() { return &___m_Settings_1; }
	inline void set_m_Settings_1(Settings_tC9C0AEE3013633FFCEA5FDFD2D15E71EB7251724  value)
	{
		___m_Settings_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DITHERINGMODEL_T563302E6CCA426980051A9DD4BE43D907032077F_H
#ifndef EYEADAPTATIONTYPE_T4F58B587481FC6D1F5DD5A4775362728CEBBEBB5_H
#define EYEADAPTATIONTYPE_T4F58B587481FC6D1F5DD5A4775362728CEBBEBB5_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.EyeAdaptationModel/EyeAdaptationType
struct  EyeAdaptationType_t4F58B587481FC6D1F5DD5A4775362728CEBBEBB5 
{
public:
	// System.Int32 UnityEngine.PostProcessing.EyeAdaptationModel/EyeAdaptationType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(EyeAdaptationType_t4F58B587481FC6D1F5DD5A4775362728CEBBEBB5, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EYEADAPTATIONTYPE_T4F58B587481FC6D1F5DD5A4775362728CEBBEBB5_H
#ifndef FOGMODEL_TCFF533017C35BAD8A878AC1912F1545DA5D1958B_H
#define FOGMODEL_TCFF533017C35BAD8A878AC1912F1545DA5D1958B_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.FogModel
struct  FogModel_tCFF533017C35BAD8A878AC1912F1545DA5D1958B  : public PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A
{
public:
	// UnityEngine.PostProcessing.FogModel/Settings UnityEngine.PostProcessing.FogModel::m_Settings
	Settings_tA824AD6B5D555CEB742A622222775333124B2107  ___m_Settings_1;

public:
	inline static int32_t get_offset_of_m_Settings_1() { return static_cast<int32_t>(offsetof(FogModel_tCFF533017C35BAD8A878AC1912F1545DA5D1958B, ___m_Settings_1)); }
	inline Settings_tA824AD6B5D555CEB742A622222775333124B2107  get_m_Settings_1() const { return ___m_Settings_1; }
	inline Settings_tA824AD6B5D555CEB742A622222775333124B2107 * get_address_of_m_Settings_1() { return &___m_Settings_1; }
	inline void set_m_Settings_1(Settings_tA824AD6B5D555CEB742A622222775333124B2107  value)
	{
		___m_Settings_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // FOGMODEL_TCFF533017C35BAD8A878AC1912F1545DA5D1958B_H
#ifndef GRAINMODEL_T9E9F9606895937388BD98DDBD0C12D33D820517A_H
#define GRAINMODEL_T9E9F9606895937388BD98DDBD0C12D33D820517A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.GrainModel
struct  GrainModel_t9E9F9606895937388BD98DDBD0C12D33D820517A  : public PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A
{
public:
	// UnityEngine.PostProcessing.GrainModel/Settings UnityEngine.PostProcessing.GrainModel::m_Settings
	Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F  ___m_Settings_1;

public:
	inline static int32_t get_offset_of_m_Settings_1() { return static_cast<int32_t>(offsetof(GrainModel_t9E9F9606895937388BD98DDBD0C12D33D820517A, ___m_Settings_1)); }
	inline Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F  get_m_Settings_1() const { return ___m_Settings_1; }
	inline Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F * get_address_of_m_Settings_1() { return &___m_Settings_1; }
	inline void set_m_Settings_1(Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F  value)
	{
		___m_Settings_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // GRAINMODEL_T9E9F9606895937388BD98DDBD0C12D33D820517A_H
#ifndef MOTIONBLURMODEL_TF9261A288A5BDE37488E0D6F1EBF060FB528BCC3_H
#define MOTIONBLURMODEL_TF9261A288A5BDE37488E0D6F1EBF060FB528BCC3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.MotionBlurModel
struct  MotionBlurModel_tF9261A288A5BDE37488E0D6F1EBF060FB528BCC3  : public PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A
{
public:
	// UnityEngine.PostProcessing.MotionBlurModel/Settings UnityEngine.PostProcessing.MotionBlurModel::m_Settings
	Settings_t6272550371AE697276AC2B9E97B10C20531B4A02  ___m_Settings_1;

public:
	inline static int32_t get_offset_of_m_Settings_1() { return static_cast<int32_t>(offsetof(MotionBlurModel_tF9261A288A5BDE37488E0D6F1EBF060FB528BCC3, ___m_Settings_1)); }
	inline Settings_t6272550371AE697276AC2B9E97B10C20531B4A02  get_m_Settings_1() const { return ___m_Settings_1; }
	inline Settings_t6272550371AE697276AC2B9E97B10C20531B4A02 * get_address_of_m_Settings_1() { return &___m_Settings_1; }
	inline void set_m_Settings_1(Settings_t6272550371AE697276AC2B9E97B10C20531B4A02  value)
	{
		___m_Settings_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MOTIONBLURMODEL_TF9261A288A5BDE37488E0D6F1EBF060FB528BCC3_H
#ifndef SSRREFLECTIONBLENDTYPE_T11182016FBBAAEA4C9480BB658E7563133E34AF9_H
#define SSRREFLECTIONBLENDTYPE_T11182016FBBAAEA4C9480BB658E7563133E34AF9_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ScreenSpaceReflectionModel/SSRReflectionBlendType
struct  SSRReflectionBlendType_t11182016FBBAAEA4C9480BB658E7563133E34AF9 
{
public:
	// System.Int32 UnityEngine.PostProcessing.ScreenSpaceReflectionModel/SSRReflectionBlendType::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(SSRReflectionBlendType_t11182016FBBAAEA4C9480BB658E7563133E34AF9, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SSRREFLECTIONBLENDTYPE_T11182016FBBAAEA4C9480BB658E7563133E34AF9_H
#ifndef SSRRESOLUTION_T40118FB40978EC7A537F3DF56576259886E87CA7_H
#define SSRRESOLUTION_T40118FB40978EC7A537F3DF56576259886E87CA7_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ScreenSpaceReflectionModel/SSRResolution
struct  SSRResolution_t40118FB40978EC7A537F3DF56576259886E87CA7 
{
public:
	// System.Int32 UnityEngine.PostProcessing.ScreenSpaceReflectionModel/SSRResolution::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(SSRResolution_t40118FB40978EC7A537F3DF56576259886E87CA7, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SSRRESOLUTION_T40118FB40978EC7A537F3DF56576259886E87CA7_H
#ifndef USERLUTMODEL_T99960CD2432509AEAEF58A93BF15F710627939E3_H
#define USERLUTMODEL_T99960CD2432509AEAEF58A93BF15F710627939E3_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.UserLutModel
struct  UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3  : public PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A
{
public:
	// UnityEngine.PostProcessing.UserLutModel/Settings UnityEngine.PostProcessing.UserLutModel::m_Settings
	Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  ___m_Settings_1;

public:
	inline static int32_t get_offset_of_m_Settings_1() { return static_cast<int32_t>(offsetof(UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3, ___m_Settings_1)); }
	inline Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  get_m_Settings_1() const { return ___m_Settings_1; }
	inline Settings_t89579C94217BC0734AF7DE292787FC983E2B4313 * get_address_of_m_Settings_1() { return &___m_Settings_1; }
	inline void set_m_Settings_1(Settings_t89579C94217BC0734AF7DE292787FC983E2B4313  value)
	{
		___m_Settings_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // USERLUTMODEL_T99960CD2432509AEAEF58A93BF15F710627939E3_H
#ifndef MODE_T78BB10CCA9904C7105408E016CBC0AF7585A625D_H
#define MODE_T78BB10CCA9904C7105408E016CBC0AF7585A625D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.VignetteModel/Mode
struct  Mode_t78BB10CCA9904C7105408E016CBC0AF7585A625D 
{
public:
	// System.Int32 UnityEngine.PostProcessing.VignetteModel/Mode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Mode_t78BB10CCA9904C7105408E016CBC0AF7585A625D, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MODE_T78BB10CCA9904C7105408E016CBC0AF7585A625D_H
#ifndef COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#define COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Component
struct  Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COMPONENT_T05064EF382ABCAF4B8C94F8A350EA85184C26621_H
#ifndef SETTINGS_T897B8FE3086F458E5E210D35F39B494A88494591_H
#define SETTINGS_T897B8FE3086F458E5E210D35F39B494A88494591_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.BuiltinDebugViewsModel/Settings
struct  Settings_t897B8FE3086F458E5E210D35F39B494A88494591 
{
public:
	// UnityEngine.PostProcessing.BuiltinDebugViewsModel/Mode UnityEngine.PostProcessing.BuiltinDebugViewsModel/Settings::mode
	int32_t ___mode_0;
	// UnityEngine.PostProcessing.BuiltinDebugViewsModel/DepthSettings UnityEngine.PostProcessing.BuiltinDebugViewsModel/Settings::depth
	DepthSettings_tC484EB6F5B3327CF16840634323AF5CFFEE126EC  ___depth_1;
	// UnityEngine.PostProcessing.BuiltinDebugViewsModel/MotionVectorsSettings UnityEngine.PostProcessing.BuiltinDebugViewsModel/Settings::motionVectors
	MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256  ___motionVectors_2;

public:
	inline static int32_t get_offset_of_mode_0() { return static_cast<int32_t>(offsetof(Settings_t897B8FE3086F458E5E210D35F39B494A88494591, ___mode_0)); }
	inline int32_t get_mode_0() const { return ___mode_0; }
	inline int32_t* get_address_of_mode_0() { return &___mode_0; }
	inline void set_mode_0(int32_t value)
	{
		___mode_0 = value;
	}

	inline static int32_t get_offset_of_depth_1() { return static_cast<int32_t>(offsetof(Settings_t897B8FE3086F458E5E210D35F39B494A88494591, ___depth_1)); }
	inline DepthSettings_tC484EB6F5B3327CF16840634323AF5CFFEE126EC  get_depth_1() const { return ___depth_1; }
	inline DepthSettings_tC484EB6F5B3327CF16840634323AF5CFFEE126EC * get_address_of_depth_1() { return &___depth_1; }
	inline void set_depth_1(DepthSettings_tC484EB6F5B3327CF16840634323AF5CFFEE126EC  value)
	{
		___depth_1 = value;
	}

	inline static int32_t get_offset_of_motionVectors_2() { return static_cast<int32_t>(offsetof(Settings_t897B8FE3086F458E5E210D35F39B494A88494591, ___motionVectors_2)); }
	inline MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256  get_motionVectors_2() const { return ___motionVectors_2; }
	inline MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256 * get_address_of_motionVectors_2() { return &___motionVectors_2; }
	inline void set_motionVectors_2(MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256  value)
	{
		___motionVectors_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SETTINGS_T897B8FE3086F458E5E210D35F39B494A88494591_H
#ifndef COLORWHEELSSETTINGS_T9C91F8B31A98943530FDFC38F386D98874501EC8_H
#define COLORWHEELSSETTINGS_T9C91F8B31A98943530FDFC38F386D98874501EC8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ColorGradingModel/ColorWheelsSettings
struct  ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8 
{
public:
	// UnityEngine.PostProcessing.ColorGradingModel/ColorWheelMode UnityEngine.PostProcessing.ColorGradingModel/ColorWheelsSettings::mode
	int32_t ___mode_0;
	// UnityEngine.PostProcessing.ColorGradingModel/LogWheelsSettings UnityEngine.PostProcessing.ColorGradingModel/ColorWheelsSettings::log
	LogWheelsSettings_t6946B0985F2ECDA5D31B31D9DC70072ED0819EF5  ___log_1;
	// UnityEngine.PostProcessing.ColorGradingModel/LinearWheelsSettings UnityEngine.PostProcessing.ColorGradingModel/ColorWheelsSettings::linear
	LinearWheelsSettings_tA2E68F6BF46B81203AF36DCB129409CAB51EC704  ___linear_2;

public:
	inline static int32_t get_offset_of_mode_0() { return static_cast<int32_t>(offsetof(ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8, ___mode_0)); }
	inline int32_t get_mode_0() const { return ___mode_0; }
	inline int32_t* get_address_of_mode_0() { return &___mode_0; }
	inline void set_mode_0(int32_t value)
	{
		___mode_0 = value;
	}

	inline static int32_t get_offset_of_log_1() { return static_cast<int32_t>(offsetof(ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8, ___log_1)); }
	inline LogWheelsSettings_t6946B0985F2ECDA5D31B31D9DC70072ED0819EF5  get_log_1() const { return ___log_1; }
	inline LogWheelsSettings_t6946B0985F2ECDA5D31B31D9DC70072ED0819EF5 * get_address_of_log_1() { return &___log_1; }
	inline void set_log_1(LogWheelsSettings_t6946B0985F2ECDA5D31B31D9DC70072ED0819EF5  value)
	{
		___log_1 = value;
	}

	inline static int32_t get_offset_of_linear_2() { return static_cast<int32_t>(offsetof(ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8, ___linear_2)); }
	inline LinearWheelsSettings_tA2E68F6BF46B81203AF36DCB129409CAB51EC704  get_linear_2() const { return ___linear_2; }
	inline LinearWheelsSettings_tA2E68F6BF46B81203AF36DCB129409CAB51EC704 * get_address_of_linear_2() { return &___linear_2; }
	inline void set_linear_2(LinearWheelsSettings_tA2E68F6BF46B81203AF36DCB129409CAB51EC704  value)
	{
		___linear_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLORWHEELSSETTINGS_T9C91F8B31A98943530FDFC38F386D98874501EC8_H
#ifndef TONEMAPPINGSETTINGS_T6325A1335977835D76781574FA3E47A97B7179DC_H
#define TONEMAPPINGSETTINGS_T6325A1335977835D76781574FA3E47A97B7179DC_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ColorGradingModel/TonemappingSettings
struct  TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC 
{
public:
	// UnityEngine.PostProcessing.ColorGradingModel/Tonemapper UnityEngine.PostProcessing.ColorGradingModel/TonemappingSettings::tonemapper
	int32_t ___tonemapper_0;
	// System.Single UnityEngine.PostProcessing.ColorGradingModel/TonemappingSettings::neutralBlackIn
	float ___neutralBlackIn_1;
	// System.Single UnityEngine.PostProcessing.ColorGradingModel/TonemappingSettings::neutralWhiteIn
	float ___neutralWhiteIn_2;
	// System.Single UnityEngine.PostProcessing.ColorGradingModel/TonemappingSettings::neutralBlackOut
	float ___neutralBlackOut_3;
	// System.Single UnityEngine.PostProcessing.ColorGradingModel/TonemappingSettings::neutralWhiteOut
	float ___neutralWhiteOut_4;
	// System.Single UnityEngine.PostProcessing.ColorGradingModel/TonemappingSettings::neutralWhiteLevel
	float ___neutralWhiteLevel_5;
	// System.Single UnityEngine.PostProcessing.ColorGradingModel/TonemappingSettings::neutralWhiteClip
	float ___neutralWhiteClip_6;

public:
	inline static int32_t get_offset_of_tonemapper_0() { return static_cast<int32_t>(offsetof(TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC, ___tonemapper_0)); }
	inline int32_t get_tonemapper_0() const { return ___tonemapper_0; }
	inline int32_t* get_address_of_tonemapper_0() { return &___tonemapper_0; }
	inline void set_tonemapper_0(int32_t value)
	{
		___tonemapper_0 = value;
	}

	inline static int32_t get_offset_of_neutralBlackIn_1() { return static_cast<int32_t>(offsetof(TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC, ___neutralBlackIn_1)); }
	inline float get_neutralBlackIn_1() const { return ___neutralBlackIn_1; }
	inline float* get_address_of_neutralBlackIn_1() { return &___neutralBlackIn_1; }
	inline void set_neutralBlackIn_1(float value)
	{
		___neutralBlackIn_1 = value;
	}

	inline static int32_t get_offset_of_neutralWhiteIn_2() { return static_cast<int32_t>(offsetof(TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC, ___neutralWhiteIn_2)); }
	inline float get_neutralWhiteIn_2() const { return ___neutralWhiteIn_2; }
	inline float* get_address_of_neutralWhiteIn_2() { return &___neutralWhiteIn_2; }
	inline void set_neutralWhiteIn_2(float value)
	{
		___neutralWhiteIn_2 = value;
	}

	inline static int32_t get_offset_of_neutralBlackOut_3() { return static_cast<int32_t>(offsetof(TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC, ___neutralBlackOut_3)); }
	inline float get_neutralBlackOut_3() const { return ___neutralBlackOut_3; }
	inline float* get_address_of_neutralBlackOut_3() { return &___neutralBlackOut_3; }
	inline void set_neutralBlackOut_3(float value)
	{
		___neutralBlackOut_3 = value;
	}

	inline static int32_t get_offset_of_neutralWhiteOut_4() { return static_cast<int32_t>(offsetof(TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC, ___neutralWhiteOut_4)); }
	inline float get_neutralWhiteOut_4() const { return ___neutralWhiteOut_4; }
	inline float* get_address_of_neutralWhiteOut_4() { return &___neutralWhiteOut_4; }
	inline void set_neutralWhiteOut_4(float value)
	{
		___neutralWhiteOut_4 = value;
	}

	inline static int32_t get_offset_of_neutralWhiteLevel_5() { return static_cast<int32_t>(offsetof(TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC, ___neutralWhiteLevel_5)); }
	inline float get_neutralWhiteLevel_5() const { return ___neutralWhiteLevel_5; }
	inline float* get_address_of_neutralWhiteLevel_5() { return &___neutralWhiteLevel_5; }
	inline void set_neutralWhiteLevel_5(float value)
	{
		___neutralWhiteLevel_5 = value;
	}

	inline static int32_t get_offset_of_neutralWhiteClip_6() { return static_cast<int32_t>(offsetof(TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC, ___neutralWhiteClip_6)); }
	inline float get_neutralWhiteClip_6() const { return ___neutralWhiteClip_6; }
	inline float* get_address_of_neutralWhiteClip_6() { return &___neutralWhiteClip_6; }
	inline void set_neutralWhiteClip_6(float value)
	{
		___neutralWhiteClip_6 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // TONEMAPPINGSETTINGS_T6325A1335977835D76781574FA3E47A97B7179DC_H
#ifndef SETTINGS_T5F3D078AA124139ACFD469537C724B81EECAE64E_H
#define SETTINGS_T5F3D078AA124139ACFD469537C724B81EECAE64E_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.DepthOfFieldModel/Settings
struct  Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E 
{
public:
	// System.Single UnityEngine.PostProcessing.DepthOfFieldModel/Settings::focusDistance
	float ___focusDistance_0;
	// System.Single UnityEngine.PostProcessing.DepthOfFieldModel/Settings::aperture
	float ___aperture_1;
	// System.Single UnityEngine.PostProcessing.DepthOfFieldModel/Settings::focalLength
	float ___focalLength_2;
	// System.Boolean UnityEngine.PostProcessing.DepthOfFieldModel/Settings::useCameraFov
	bool ___useCameraFov_3;
	// UnityEngine.PostProcessing.DepthOfFieldModel/KernelSize UnityEngine.PostProcessing.DepthOfFieldModel/Settings::kernelSize
	int32_t ___kernelSize_4;

public:
	inline static int32_t get_offset_of_focusDistance_0() { return static_cast<int32_t>(offsetof(Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E, ___focusDistance_0)); }
	inline float get_focusDistance_0() const { return ___focusDistance_0; }
	inline float* get_address_of_focusDistance_0() { return &___focusDistance_0; }
	inline void set_focusDistance_0(float value)
	{
		___focusDistance_0 = value;
	}

	inline static int32_t get_offset_of_aperture_1() { return static_cast<int32_t>(offsetof(Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E, ___aperture_1)); }
	inline float get_aperture_1() const { return ___aperture_1; }
	inline float* get_address_of_aperture_1() { return &___aperture_1; }
	inline void set_aperture_1(float value)
	{
		___aperture_1 = value;
	}

	inline static int32_t get_offset_of_focalLength_2() { return static_cast<int32_t>(offsetof(Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E, ___focalLength_2)); }
	inline float get_focalLength_2() const { return ___focalLength_2; }
	inline float* get_address_of_focalLength_2() { return &___focalLength_2; }
	inline void set_focalLength_2(float value)
	{
		___focalLength_2 = value;
	}

	inline static int32_t get_offset_of_useCameraFov_3() { return static_cast<int32_t>(offsetof(Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E, ___useCameraFov_3)); }
	inline bool get_useCameraFov_3() const { return ___useCameraFov_3; }
	inline bool* get_address_of_useCameraFov_3() { return &___useCameraFov_3; }
	inline void set_useCameraFov_3(bool value)
	{
		___useCameraFov_3 = value;
	}

	inline static int32_t get_offset_of_kernelSize_4() { return static_cast<int32_t>(offsetof(Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E, ___kernelSize_4)); }
	inline int32_t get_kernelSize_4() const { return ___kernelSize_4; }
	inline int32_t* get_address_of_kernelSize_4() { return &___kernelSize_4; }
	inline void set_kernelSize_4(int32_t value)
	{
		___kernelSize_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.DepthOfFieldModel/Settings
struct Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E_marshaled_pinvoke
{
	float ___focusDistance_0;
	float ___aperture_1;
	float ___focalLength_2;
	int32_t ___useCameraFov_3;
	int32_t ___kernelSize_4;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.DepthOfFieldModel/Settings
struct Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E_marshaled_com
{
	float ___focusDistance_0;
	float ___aperture_1;
	float ___focalLength_2;
	int32_t ___useCameraFov_3;
	int32_t ___kernelSize_4;
};
#endif // SETTINGS_T5F3D078AA124139ACFD469537C724B81EECAE64E_H
#ifndef SETTINGS_T8A8457FAF6223DD887350322DC6D951891572426_H
#define SETTINGS_T8A8457FAF6223DD887350322DC6D951891572426_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.EyeAdaptationModel/Settings
struct  Settings_t8A8457FAF6223DD887350322DC6D951891572426 
{
public:
	// System.Single UnityEngine.PostProcessing.EyeAdaptationModel/Settings::lowPercent
	float ___lowPercent_0;
	// System.Single UnityEngine.PostProcessing.EyeAdaptationModel/Settings::highPercent
	float ___highPercent_1;
	// System.Single UnityEngine.PostProcessing.EyeAdaptationModel/Settings::minLuminance
	float ___minLuminance_2;
	// System.Single UnityEngine.PostProcessing.EyeAdaptationModel/Settings::maxLuminance
	float ___maxLuminance_3;
	// System.Single UnityEngine.PostProcessing.EyeAdaptationModel/Settings::keyValue
	float ___keyValue_4;
	// System.Boolean UnityEngine.PostProcessing.EyeAdaptationModel/Settings::dynamicKeyValue
	bool ___dynamicKeyValue_5;
	// UnityEngine.PostProcessing.EyeAdaptationModel/EyeAdaptationType UnityEngine.PostProcessing.EyeAdaptationModel/Settings::adaptationType
	int32_t ___adaptationType_6;
	// System.Single UnityEngine.PostProcessing.EyeAdaptationModel/Settings::speedUp
	float ___speedUp_7;
	// System.Single UnityEngine.PostProcessing.EyeAdaptationModel/Settings::speedDown
	float ___speedDown_8;
	// System.Int32 UnityEngine.PostProcessing.EyeAdaptationModel/Settings::logMin
	int32_t ___logMin_9;
	// System.Int32 UnityEngine.PostProcessing.EyeAdaptationModel/Settings::logMax
	int32_t ___logMax_10;

public:
	inline static int32_t get_offset_of_lowPercent_0() { return static_cast<int32_t>(offsetof(Settings_t8A8457FAF6223DD887350322DC6D951891572426, ___lowPercent_0)); }
	inline float get_lowPercent_0() const { return ___lowPercent_0; }
	inline float* get_address_of_lowPercent_0() { return &___lowPercent_0; }
	inline void set_lowPercent_0(float value)
	{
		___lowPercent_0 = value;
	}

	inline static int32_t get_offset_of_highPercent_1() { return static_cast<int32_t>(offsetof(Settings_t8A8457FAF6223DD887350322DC6D951891572426, ___highPercent_1)); }
	inline float get_highPercent_1() const { return ___highPercent_1; }
	inline float* get_address_of_highPercent_1() { return &___highPercent_1; }
	inline void set_highPercent_1(float value)
	{
		___highPercent_1 = value;
	}

	inline static int32_t get_offset_of_minLuminance_2() { return static_cast<int32_t>(offsetof(Settings_t8A8457FAF6223DD887350322DC6D951891572426, ___minLuminance_2)); }
	inline float get_minLuminance_2() const { return ___minLuminance_2; }
	inline float* get_address_of_minLuminance_2() { return &___minLuminance_2; }
	inline void set_minLuminance_2(float value)
	{
		___minLuminance_2 = value;
	}

	inline static int32_t get_offset_of_maxLuminance_3() { return static_cast<int32_t>(offsetof(Settings_t8A8457FAF6223DD887350322DC6D951891572426, ___maxLuminance_3)); }
	inline float get_maxLuminance_3() const { return ___maxLuminance_3; }
	inline float* get_address_of_maxLuminance_3() { return &___maxLuminance_3; }
	inline void set_maxLuminance_3(float value)
	{
		___maxLuminance_3 = value;
	}

	inline static int32_t get_offset_of_keyValue_4() { return static_cast<int32_t>(offsetof(Settings_t8A8457FAF6223DD887350322DC6D951891572426, ___keyValue_4)); }
	inline float get_keyValue_4() const { return ___keyValue_4; }
	inline float* get_address_of_keyValue_4() { return &___keyValue_4; }
	inline void set_keyValue_4(float value)
	{
		___keyValue_4 = value;
	}

	inline static int32_t get_offset_of_dynamicKeyValue_5() { return static_cast<int32_t>(offsetof(Settings_t8A8457FAF6223DD887350322DC6D951891572426, ___dynamicKeyValue_5)); }
	inline bool get_dynamicKeyValue_5() const { return ___dynamicKeyValue_5; }
	inline bool* get_address_of_dynamicKeyValue_5() { return &___dynamicKeyValue_5; }
	inline void set_dynamicKeyValue_5(bool value)
	{
		___dynamicKeyValue_5 = value;
	}

	inline static int32_t get_offset_of_adaptationType_6() { return static_cast<int32_t>(offsetof(Settings_t8A8457FAF6223DD887350322DC6D951891572426, ___adaptationType_6)); }
	inline int32_t get_adaptationType_6() const { return ___adaptationType_6; }
	inline int32_t* get_address_of_adaptationType_6() { return &___adaptationType_6; }
	inline void set_adaptationType_6(int32_t value)
	{
		___adaptationType_6 = value;
	}

	inline static int32_t get_offset_of_speedUp_7() { return static_cast<int32_t>(offsetof(Settings_t8A8457FAF6223DD887350322DC6D951891572426, ___speedUp_7)); }
	inline float get_speedUp_7() const { return ___speedUp_7; }
	inline float* get_address_of_speedUp_7() { return &___speedUp_7; }
	inline void set_speedUp_7(float value)
	{
		___speedUp_7 = value;
	}

	inline static int32_t get_offset_of_speedDown_8() { return static_cast<int32_t>(offsetof(Settings_t8A8457FAF6223DD887350322DC6D951891572426, ___speedDown_8)); }
	inline float get_speedDown_8() const { return ___speedDown_8; }
	inline float* get_address_of_speedDown_8() { return &___speedDown_8; }
	inline void set_speedDown_8(float value)
	{
		___speedDown_8 = value;
	}

	inline static int32_t get_offset_of_logMin_9() { return static_cast<int32_t>(offsetof(Settings_t8A8457FAF6223DD887350322DC6D951891572426, ___logMin_9)); }
	inline int32_t get_logMin_9() const { return ___logMin_9; }
	inline int32_t* get_address_of_logMin_9() { return &___logMin_9; }
	inline void set_logMin_9(int32_t value)
	{
		___logMin_9 = value;
	}

	inline static int32_t get_offset_of_logMax_10() { return static_cast<int32_t>(offsetof(Settings_t8A8457FAF6223DD887350322DC6D951891572426, ___logMax_10)); }
	inline int32_t get_logMax_10() const { return ___logMax_10; }
	inline int32_t* get_address_of_logMax_10() { return &___logMax_10; }
	inline void set_logMax_10(int32_t value)
	{
		___logMax_10 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.EyeAdaptationModel/Settings
struct Settings_t8A8457FAF6223DD887350322DC6D951891572426_marshaled_pinvoke
{
	float ___lowPercent_0;
	float ___highPercent_1;
	float ___minLuminance_2;
	float ___maxLuminance_3;
	float ___keyValue_4;
	int32_t ___dynamicKeyValue_5;
	int32_t ___adaptationType_6;
	float ___speedUp_7;
	float ___speedDown_8;
	int32_t ___logMin_9;
	int32_t ___logMax_10;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.EyeAdaptationModel/Settings
struct Settings_t8A8457FAF6223DD887350322DC6D951891572426_marshaled_com
{
	float ___lowPercent_0;
	float ___highPercent_1;
	float ___minLuminance_2;
	float ___maxLuminance_3;
	float ___keyValue_4;
	int32_t ___dynamicKeyValue_5;
	int32_t ___adaptationType_6;
	float ___speedUp_7;
	float ___speedDown_8;
	int32_t ___logMin_9;
	int32_t ___logMax_10;
};
#endif // SETTINGS_T8A8457FAF6223DD887350322DC6D951891572426_H
#ifndef REFLECTIONSETTINGS_T0E6A92FF17732807EDA06E014001FF6F5A65DC4C_H
#define REFLECTIONSETTINGS_T0E6A92FF17732807EDA06E014001FF6F5A65DC4C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ReflectionSettings
struct  ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C 
{
public:
	// UnityEngine.PostProcessing.ScreenSpaceReflectionModel/SSRReflectionBlendType UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ReflectionSettings::blendType
	int32_t ___blendType_0;
	// UnityEngine.PostProcessing.ScreenSpaceReflectionModel/SSRResolution UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ReflectionSettings::reflectionQuality
	int32_t ___reflectionQuality_1;
	// System.Single UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ReflectionSettings::maxDistance
	float ___maxDistance_2;
	// System.Int32 UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ReflectionSettings::iterationCount
	int32_t ___iterationCount_3;
	// System.Int32 UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ReflectionSettings::stepSize
	int32_t ___stepSize_4;
	// System.Single UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ReflectionSettings::widthModifier
	float ___widthModifier_5;
	// System.Single UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ReflectionSettings::reflectionBlur
	float ___reflectionBlur_6;
	// System.Boolean UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ReflectionSettings::reflectBackfaces
	bool ___reflectBackfaces_7;

public:
	inline static int32_t get_offset_of_blendType_0() { return static_cast<int32_t>(offsetof(ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C, ___blendType_0)); }
	inline int32_t get_blendType_0() const { return ___blendType_0; }
	inline int32_t* get_address_of_blendType_0() { return &___blendType_0; }
	inline void set_blendType_0(int32_t value)
	{
		___blendType_0 = value;
	}

	inline static int32_t get_offset_of_reflectionQuality_1() { return static_cast<int32_t>(offsetof(ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C, ___reflectionQuality_1)); }
	inline int32_t get_reflectionQuality_1() const { return ___reflectionQuality_1; }
	inline int32_t* get_address_of_reflectionQuality_1() { return &___reflectionQuality_1; }
	inline void set_reflectionQuality_1(int32_t value)
	{
		___reflectionQuality_1 = value;
	}

	inline static int32_t get_offset_of_maxDistance_2() { return static_cast<int32_t>(offsetof(ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C, ___maxDistance_2)); }
	inline float get_maxDistance_2() const { return ___maxDistance_2; }
	inline float* get_address_of_maxDistance_2() { return &___maxDistance_2; }
	inline void set_maxDistance_2(float value)
	{
		___maxDistance_2 = value;
	}

	inline static int32_t get_offset_of_iterationCount_3() { return static_cast<int32_t>(offsetof(ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C, ___iterationCount_3)); }
	inline int32_t get_iterationCount_3() const { return ___iterationCount_3; }
	inline int32_t* get_address_of_iterationCount_3() { return &___iterationCount_3; }
	inline void set_iterationCount_3(int32_t value)
	{
		___iterationCount_3 = value;
	}

	inline static int32_t get_offset_of_stepSize_4() { return static_cast<int32_t>(offsetof(ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C, ___stepSize_4)); }
	inline int32_t get_stepSize_4() const { return ___stepSize_4; }
	inline int32_t* get_address_of_stepSize_4() { return &___stepSize_4; }
	inline void set_stepSize_4(int32_t value)
	{
		___stepSize_4 = value;
	}

	inline static int32_t get_offset_of_widthModifier_5() { return static_cast<int32_t>(offsetof(ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C, ___widthModifier_5)); }
	inline float get_widthModifier_5() const { return ___widthModifier_5; }
	inline float* get_address_of_widthModifier_5() { return &___widthModifier_5; }
	inline void set_widthModifier_5(float value)
	{
		___widthModifier_5 = value;
	}

	inline static int32_t get_offset_of_reflectionBlur_6() { return static_cast<int32_t>(offsetof(ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C, ___reflectionBlur_6)); }
	inline float get_reflectionBlur_6() const { return ___reflectionBlur_6; }
	inline float* get_address_of_reflectionBlur_6() { return &___reflectionBlur_6; }
	inline void set_reflectionBlur_6(float value)
	{
		___reflectionBlur_6 = value;
	}

	inline static int32_t get_offset_of_reflectBackfaces_7() { return static_cast<int32_t>(offsetof(ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C, ___reflectBackfaces_7)); }
	inline bool get_reflectBackfaces_7() const { return ___reflectBackfaces_7; }
	inline bool* get_address_of_reflectBackfaces_7() { return &___reflectBackfaces_7; }
	inline void set_reflectBackfaces_7(bool value)
	{
		___reflectBackfaces_7 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ReflectionSettings
struct ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C_marshaled_pinvoke
{
	int32_t ___blendType_0;
	int32_t ___reflectionQuality_1;
	float ___maxDistance_2;
	int32_t ___iterationCount_3;
	int32_t ___stepSize_4;
	float ___widthModifier_5;
	float ___reflectionBlur_6;
	int32_t ___reflectBackfaces_7;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ReflectionSettings
struct ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C_marshaled_com
{
	int32_t ___blendType_0;
	int32_t ___reflectionQuality_1;
	float ___maxDistance_2;
	int32_t ___iterationCount_3;
	int32_t ___stepSize_4;
	float ___widthModifier_5;
	float ___reflectionBlur_6;
	int32_t ___reflectBackfaces_7;
};
#endif // REFLECTIONSETTINGS_T0E6A92FF17732807EDA06E014001FF6F5A65DC4C_H
#ifndef SETTINGS_T38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_H
#define SETTINGS_T38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.VignetteModel/Settings
struct  Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C 
{
public:
	// UnityEngine.PostProcessing.VignetteModel/Mode UnityEngine.PostProcessing.VignetteModel/Settings::mode
	int32_t ___mode_0;
	// UnityEngine.Color UnityEngine.PostProcessing.VignetteModel/Settings::color
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___color_1;
	// UnityEngine.Vector2 UnityEngine.PostProcessing.VignetteModel/Settings::center
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___center_2;
	// System.Single UnityEngine.PostProcessing.VignetteModel/Settings::intensity
	float ___intensity_3;
	// System.Single UnityEngine.PostProcessing.VignetteModel/Settings::smoothness
	float ___smoothness_4;
	// System.Single UnityEngine.PostProcessing.VignetteModel/Settings::roundness
	float ___roundness_5;
	// UnityEngine.Texture UnityEngine.PostProcessing.VignetteModel/Settings::mask
	Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___mask_6;
	// System.Single UnityEngine.PostProcessing.VignetteModel/Settings::opacity
	float ___opacity_7;
	// System.Boolean UnityEngine.PostProcessing.VignetteModel/Settings::rounded
	bool ___rounded_8;

public:
	inline static int32_t get_offset_of_mode_0() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___mode_0)); }
	inline int32_t get_mode_0() const { return ___mode_0; }
	inline int32_t* get_address_of_mode_0() { return &___mode_0; }
	inline void set_mode_0(int32_t value)
	{
		___mode_0 = value;
	}

	inline static int32_t get_offset_of_color_1() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___color_1)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_color_1() const { return ___color_1; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_color_1() { return &___color_1; }
	inline void set_color_1(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___color_1 = value;
	}

	inline static int32_t get_offset_of_center_2() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___center_2)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_center_2() const { return ___center_2; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_center_2() { return &___center_2; }
	inline void set_center_2(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___center_2 = value;
	}

	inline static int32_t get_offset_of_intensity_3() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___intensity_3)); }
	inline float get_intensity_3() const { return ___intensity_3; }
	inline float* get_address_of_intensity_3() { return &___intensity_3; }
	inline void set_intensity_3(float value)
	{
		___intensity_3 = value;
	}

	inline static int32_t get_offset_of_smoothness_4() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___smoothness_4)); }
	inline float get_smoothness_4() const { return ___smoothness_4; }
	inline float* get_address_of_smoothness_4() { return &___smoothness_4; }
	inline void set_smoothness_4(float value)
	{
		___smoothness_4 = value;
	}

	inline static int32_t get_offset_of_roundness_5() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___roundness_5)); }
	inline float get_roundness_5() const { return ___roundness_5; }
	inline float* get_address_of_roundness_5() { return &___roundness_5; }
	inline void set_roundness_5(float value)
	{
		___roundness_5 = value;
	}

	inline static int32_t get_offset_of_mask_6() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___mask_6)); }
	inline Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * get_mask_6() const { return ___mask_6; }
	inline Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 ** get_address_of_mask_6() { return &___mask_6; }
	inline void set_mask_6(Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * value)
	{
		___mask_6 = value;
		Il2CppCodeGenWriteBarrier((&___mask_6), value);
	}

	inline static int32_t get_offset_of_opacity_7() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___opacity_7)); }
	inline float get_opacity_7() const { return ___opacity_7; }
	inline float* get_address_of_opacity_7() { return &___opacity_7; }
	inline void set_opacity_7(float value)
	{
		___opacity_7 = value;
	}

	inline static int32_t get_offset_of_rounded_8() { return static_cast<int32_t>(offsetof(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C, ___rounded_8)); }
	inline bool get_rounded_8() const { return ___rounded_8; }
	inline bool* get_address_of_rounded_8() { return &___rounded_8; }
	inline void set_rounded_8(bool value)
	{
		___rounded_8 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.VignetteModel/Settings
struct Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshaled_pinvoke
{
	int32_t ___mode_0;
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___color_1;
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___center_2;
	float ___intensity_3;
	float ___smoothness_4;
	float ___roundness_5;
	Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___mask_6;
	float ___opacity_7;
	int32_t ___rounded_8;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.VignetteModel/Settings
struct Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_marshaled_com
{
	int32_t ___mode_0;
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___color_1;
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___center_2;
	float ___intensity_3;
	float ___smoothness_4;
	float ___roundness_5;
	Texture_t387FE83BB848001FD06B14707AEA6D5A0F6A95F4 * ___mask_6;
	float ___opacity_7;
	int32_t ___rounded_8;
};
#endif // SETTINGS_T38E3144318C540D0811780C3FC3CF5BFE3DF9A8C_H
#ifndef SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#define SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.ScriptableObject
struct  ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_pinvoke : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
};
// Native definition for COM marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_com : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
};
#endif // SCRIPTABLEOBJECT_TAB015486CEAB714DA0D5C1BA389B84FB90427734_H
#ifndef BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#define BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.Behaviour
struct  Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8  : public Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BEHAVIOUR_TBDC7E9C3C898AD8348891B82D3E345801D920CA8_H
#ifndef BUILTINDEBUGVIEWSMODEL_T3895BEF4E3FAA223414BEB50B52AE8E40209040D_H
#define BUILTINDEBUGVIEWSMODEL_T3895BEF4E3FAA223414BEB50B52AE8E40209040D_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.BuiltinDebugViewsModel
struct  BuiltinDebugViewsModel_t3895BEF4E3FAA223414BEB50B52AE8E40209040D  : public PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A
{
public:
	// UnityEngine.PostProcessing.BuiltinDebugViewsModel/Settings UnityEngine.PostProcessing.BuiltinDebugViewsModel::m_Settings
	Settings_t897B8FE3086F458E5E210D35F39B494A88494591  ___m_Settings_1;

public:
	inline static int32_t get_offset_of_m_Settings_1() { return static_cast<int32_t>(offsetof(BuiltinDebugViewsModel_t3895BEF4E3FAA223414BEB50B52AE8E40209040D, ___m_Settings_1)); }
	inline Settings_t897B8FE3086F458E5E210D35F39B494A88494591  get_m_Settings_1() const { return ___m_Settings_1; }
	inline Settings_t897B8FE3086F458E5E210D35F39B494A88494591 * get_address_of_m_Settings_1() { return &___m_Settings_1; }
	inline void set_m_Settings_1(Settings_t897B8FE3086F458E5E210D35F39B494A88494591  value)
	{
		___m_Settings_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // BUILTINDEBUGVIEWSMODEL_T3895BEF4E3FAA223414BEB50B52AE8E40209040D_H
#ifndef SETTINGS_T48BF09637C1A12D6B94A6E21D32A58B301F6759A_H
#define SETTINGS_T48BF09637C1A12D6B94A6E21D32A58B301F6759A_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ColorGradingModel/Settings
struct  Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A 
{
public:
	// UnityEngine.PostProcessing.ColorGradingModel/TonemappingSettings UnityEngine.PostProcessing.ColorGradingModel/Settings::tonemapping
	TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC  ___tonemapping_0;
	// UnityEngine.PostProcessing.ColorGradingModel/BasicSettings UnityEngine.PostProcessing.ColorGradingModel/Settings::basic
	BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49  ___basic_1;
	// UnityEngine.PostProcessing.ColorGradingModel/ChannelMixerSettings UnityEngine.PostProcessing.ColorGradingModel/Settings::channelMixer
	ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B  ___channelMixer_2;
	// UnityEngine.PostProcessing.ColorGradingModel/ColorWheelsSettings UnityEngine.PostProcessing.ColorGradingModel/Settings::colorWheels
	ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8  ___colorWheels_3;
	// UnityEngine.PostProcessing.ColorGradingModel/CurvesSettings UnityEngine.PostProcessing.ColorGradingModel/Settings::curves
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E  ___curves_4;

public:
	inline static int32_t get_offset_of_tonemapping_0() { return static_cast<int32_t>(offsetof(Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A, ___tonemapping_0)); }
	inline TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC  get_tonemapping_0() const { return ___tonemapping_0; }
	inline TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC * get_address_of_tonemapping_0() { return &___tonemapping_0; }
	inline void set_tonemapping_0(TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC  value)
	{
		___tonemapping_0 = value;
	}

	inline static int32_t get_offset_of_basic_1() { return static_cast<int32_t>(offsetof(Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A, ___basic_1)); }
	inline BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49  get_basic_1() const { return ___basic_1; }
	inline BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49 * get_address_of_basic_1() { return &___basic_1; }
	inline void set_basic_1(BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49  value)
	{
		___basic_1 = value;
	}

	inline static int32_t get_offset_of_channelMixer_2() { return static_cast<int32_t>(offsetof(Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A, ___channelMixer_2)); }
	inline ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B  get_channelMixer_2() const { return ___channelMixer_2; }
	inline ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B * get_address_of_channelMixer_2() { return &___channelMixer_2; }
	inline void set_channelMixer_2(ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B  value)
	{
		___channelMixer_2 = value;
	}

	inline static int32_t get_offset_of_colorWheels_3() { return static_cast<int32_t>(offsetof(Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A, ___colorWheels_3)); }
	inline ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8  get_colorWheels_3() const { return ___colorWheels_3; }
	inline ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8 * get_address_of_colorWheels_3() { return &___colorWheels_3; }
	inline void set_colorWheels_3(ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8  value)
	{
		___colorWheels_3 = value;
	}

	inline static int32_t get_offset_of_curves_4() { return static_cast<int32_t>(offsetof(Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A, ___curves_4)); }
	inline CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E  get_curves_4() const { return ___curves_4; }
	inline CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E * get_address_of_curves_4() { return &___curves_4; }
	inline void set_curves_4(CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E  value)
	{
		___curves_4 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.ColorGradingModel/Settings
struct Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A_marshaled_pinvoke
{
	TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC  ___tonemapping_0;
	BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49  ___basic_1;
	ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B  ___channelMixer_2;
	ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8  ___colorWheels_3;
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E_marshaled_pinvoke ___curves_4;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.ColorGradingModel/Settings
struct Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A_marshaled_com
{
	TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC  ___tonemapping_0;
	BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49  ___basic_1;
	ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B  ___channelMixer_2;
	ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8  ___colorWheels_3;
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E_marshaled_com ___curves_4;
};
#endif // SETTINGS_T48BF09637C1A12D6B94A6E21D32A58B301F6759A_H
#ifndef DEPTHOFFIELDMODEL_T467AC9D0D874371D108098B766B99177AE416A76_H
#define DEPTHOFFIELDMODEL_T467AC9D0D874371D108098B766B99177AE416A76_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.DepthOfFieldModel
struct  DepthOfFieldModel_t467AC9D0D874371D108098B766B99177AE416A76  : public PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A
{
public:
	// UnityEngine.PostProcessing.DepthOfFieldModel/Settings UnityEngine.PostProcessing.DepthOfFieldModel::m_Settings
	Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E  ___m_Settings_1;

public:
	inline static int32_t get_offset_of_m_Settings_1() { return static_cast<int32_t>(offsetof(DepthOfFieldModel_t467AC9D0D874371D108098B766B99177AE416A76, ___m_Settings_1)); }
	inline Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E  get_m_Settings_1() const { return ___m_Settings_1; }
	inline Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E * get_address_of_m_Settings_1() { return &___m_Settings_1; }
	inline void set_m_Settings_1(Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E  value)
	{
		___m_Settings_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // DEPTHOFFIELDMODEL_T467AC9D0D874371D108098B766B99177AE416A76_H
#ifndef EYEADAPTATIONMODEL_T1ACCFD330F4AC0B18055B102CB33E568F6354255_H
#define EYEADAPTATIONMODEL_T1ACCFD330F4AC0B18055B102CB33E568F6354255_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.EyeAdaptationModel
struct  EyeAdaptationModel_t1ACCFD330F4AC0B18055B102CB33E568F6354255  : public PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A
{
public:
	// UnityEngine.PostProcessing.EyeAdaptationModel/Settings UnityEngine.PostProcessing.EyeAdaptationModel::m_Settings
	Settings_t8A8457FAF6223DD887350322DC6D951891572426  ___m_Settings_1;

public:
	inline static int32_t get_offset_of_m_Settings_1() { return static_cast<int32_t>(offsetof(EyeAdaptationModel_t1ACCFD330F4AC0B18055B102CB33E568F6354255, ___m_Settings_1)); }
	inline Settings_t8A8457FAF6223DD887350322DC6D951891572426  get_m_Settings_1() const { return ___m_Settings_1; }
	inline Settings_t8A8457FAF6223DD887350322DC6D951891572426 * get_address_of_m_Settings_1() { return &___m_Settings_1; }
	inline void set_m_Settings_1(Settings_t8A8457FAF6223DD887350322DC6D951891572426  value)
	{
		___m_Settings_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // EYEADAPTATIONMODEL_T1ACCFD330F4AC0B18055B102CB33E568F6354255_H
#ifndef POSTPROCESSINGPROFILE_TDDAC51472A60B9B12D350E7635B49687A06A327F_H
#define POSTPROCESSINGPROFILE_TDDAC51472A60B9B12D350E7635B49687A06A327F_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.PostProcessingProfile
struct  PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F  : public ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734
{
public:
	// UnityEngine.PostProcessing.BuiltinDebugViewsModel UnityEngine.PostProcessing.PostProcessingProfile::debugViews
	BuiltinDebugViewsModel_t3895BEF4E3FAA223414BEB50B52AE8E40209040D * ___debugViews_4;
	// UnityEngine.PostProcessing.FogModel UnityEngine.PostProcessing.PostProcessingProfile::fog
	FogModel_tCFF533017C35BAD8A878AC1912F1545DA5D1958B * ___fog_5;
	// UnityEngine.PostProcessing.AntialiasingModel UnityEngine.PostProcessing.PostProcessingProfile::antialiasing
	AntialiasingModel_t816E25AD68EE2CE948F418317CB2FB664918438C * ___antialiasing_6;
	// UnityEngine.PostProcessing.AmbientOcclusionModel UnityEngine.PostProcessing.PostProcessingProfile::ambientOcclusion
	AmbientOcclusionModel_tA820D7E7EABB1F2E94CBA9C539B8BA45F36D6FF4 * ___ambientOcclusion_7;
	// UnityEngine.PostProcessing.ScreenSpaceReflectionModel UnityEngine.PostProcessing.PostProcessingProfile::screenSpaceReflection
	ScreenSpaceReflectionModel_t05FF878FC8651BE6F59BC62D0167970B047A0A82 * ___screenSpaceReflection_8;
	// UnityEngine.PostProcessing.DepthOfFieldModel UnityEngine.PostProcessing.PostProcessingProfile::depthOfField
	DepthOfFieldModel_t467AC9D0D874371D108098B766B99177AE416A76 * ___depthOfField_9;
	// UnityEngine.PostProcessing.MotionBlurModel UnityEngine.PostProcessing.PostProcessingProfile::motionBlur
	MotionBlurModel_tF9261A288A5BDE37488E0D6F1EBF060FB528BCC3 * ___motionBlur_10;
	// UnityEngine.PostProcessing.EyeAdaptationModel UnityEngine.PostProcessing.PostProcessingProfile::eyeAdaptation
	EyeAdaptationModel_t1ACCFD330F4AC0B18055B102CB33E568F6354255 * ___eyeAdaptation_11;
	// UnityEngine.PostProcessing.BloomModel UnityEngine.PostProcessing.PostProcessingProfile::bloom
	BloomModel_tE92443526105DCFC1CBCCC5693C46569B7C15FC3 * ___bloom_12;
	// UnityEngine.PostProcessing.ColorGradingModel UnityEngine.PostProcessing.PostProcessingProfile::colorGrading
	ColorGradingModel_tA35650888B77D10DAB148BD56BB3CEC13C114F89 * ___colorGrading_13;
	// UnityEngine.PostProcessing.UserLutModel UnityEngine.PostProcessing.PostProcessingProfile::userLut
	UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * ___userLut_14;
	// UnityEngine.PostProcessing.ChromaticAberrationModel UnityEngine.PostProcessing.PostProcessingProfile::chromaticAberration
	ChromaticAberrationModel_tC130D625088CD9AD6FC98DD5889D62FB32D26B9A * ___chromaticAberration_15;
	// UnityEngine.PostProcessing.GrainModel UnityEngine.PostProcessing.PostProcessingProfile::grain
	GrainModel_t9E9F9606895937388BD98DDBD0C12D33D820517A * ___grain_16;
	// UnityEngine.PostProcessing.VignetteModel UnityEngine.PostProcessing.PostProcessingProfile::vignette
	VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * ___vignette_17;
	// UnityEngine.PostProcessing.DitheringModel UnityEngine.PostProcessing.PostProcessingProfile::dithering
	DitheringModel_t563302E6CCA426980051A9DD4BE43D907032077F * ___dithering_18;

public:
	inline static int32_t get_offset_of_debugViews_4() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___debugViews_4)); }
	inline BuiltinDebugViewsModel_t3895BEF4E3FAA223414BEB50B52AE8E40209040D * get_debugViews_4() const { return ___debugViews_4; }
	inline BuiltinDebugViewsModel_t3895BEF4E3FAA223414BEB50B52AE8E40209040D ** get_address_of_debugViews_4() { return &___debugViews_4; }
	inline void set_debugViews_4(BuiltinDebugViewsModel_t3895BEF4E3FAA223414BEB50B52AE8E40209040D * value)
	{
		___debugViews_4 = value;
		Il2CppCodeGenWriteBarrier((&___debugViews_4), value);
	}

	inline static int32_t get_offset_of_fog_5() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___fog_5)); }
	inline FogModel_tCFF533017C35BAD8A878AC1912F1545DA5D1958B * get_fog_5() const { return ___fog_5; }
	inline FogModel_tCFF533017C35BAD8A878AC1912F1545DA5D1958B ** get_address_of_fog_5() { return &___fog_5; }
	inline void set_fog_5(FogModel_tCFF533017C35BAD8A878AC1912F1545DA5D1958B * value)
	{
		___fog_5 = value;
		Il2CppCodeGenWriteBarrier((&___fog_5), value);
	}

	inline static int32_t get_offset_of_antialiasing_6() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___antialiasing_6)); }
	inline AntialiasingModel_t816E25AD68EE2CE948F418317CB2FB664918438C * get_antialiasing_6() const { return ___antialiasing_6; }
	inline AntialiasingModel_t816E25AD68EE2CE948F418317CB2FB664918438C ** get_address_of_antialiasing_6() { return &___antialiasing_6; }
	inline void set_antialiasing_6(AntialiasingModel_t816E25AD68EE2CE948F418317CB2FB664918438C * value)
	{
		___antialiasing_6 = value;
		Il2CppCodeGenWriteBarrier((&___antialiasing_6), value);
	}

	inline static int32_t get_offset_of_ambientOcclusion_7() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___ambientOcclusion_7)); }
	inline AmbientOcclusionModel_tA820D7E7EABB1F2E94CBA9C539B8BA45F36D6FF4 * get_ambientOcclusion_7() const { return ___ambientOcclusion_7; }
	inline AmbientOcclusionModel_tA820D7E7EABB1F2E94CBA9C539B8BA45F36D6FF4 ** get_address_of_ambientOcclusion_7() { return &___ambientOcclusion_7; }
	inline void set_ambientOcclusion_7(AmbientOcclusionModel_tA820D7E7EABB1F2E94CBA9C539B8BA45F36D6FF4 * value)
	{
		___ambientOcclusion_7 = value;
		Il2CppCodeGenWriteBarrier((&___ambientOcclusion_7), value);
	}

	inline static int32_t get_offset_of_screenSpaceReflection_8() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___screenSpaceReflection_8)); }
	inline ScreenSpaceReflectionModel_t05FF878FC8651BE6F59BC62D0167970B047A0A82 * get_screenSpaceReflection_8() const { return ___screenSpaceReflection_8; }
	inline ScreenSpaceReflectionModel_t05FF878FC8651BE6F59BC62D0167970B047A0A82 ** get_address_of_screenSpaceReflection_8() { return &___screenSpaceReflection_8; }
	inline void set_screenSpaceReflection_8(ScreenSpaceReflectionModel_t05FF878FC8651BE6F59BC62D0167970B047A0A82 * value)
	{
		___screenSpaceReflection_8 = value;
		Il2CppCodeGenWriteBarrier((&___screenSpaceReflection_8), value);
	}

	inline static int32_t get_offset_of_depthOfField_9() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___depthOfField_9)); }
	inline DepthOfFieldModel_t467AC9D0D874371D108098B766B99177AE416A76 * get_depthOfField_9() const { return ___depthOfField_9; }
	inline DepthOfFieldModel_t467AC9D0D874371D108098B766B99177AE416A76 ** get_address_of_depthOfField_9() { return &___depthOfField_9; }
	inline void set_depthOfField_9(DepthOfFieldModel_t467AC9D0D874371D108098B766B99177AE416A76 * value)
	{
		___depthOfField_9 = value;
		Il2CppCodeGenWriteBarrier((&___depthOfField_9), value);
	}

	inline static int32_t get_offset_of_motionBlur_10() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___motionBlur_10)); }
	inline MotionBlurModel_tF9261A288A5BDE37488E0D6F1EBF060FB528BCC3 * get_motionBlur_10() const { return ___motionBlur_10; }
	inline MotionBlurModel_tF9261A288A5BDE37488E0D6F1EBF060FB528BCC3 ** get_address_of_motionBlur_10() { return &___motionBlur_10; }
	inline void set_motionBlur_10(MotionBlurModel_tF9261A288A5BDE37488E0D6F1EBF060FB528BCC3 * value)
	{
		___motionBlur_10 = value;
		Il2CppCodeGenWriteBarrier((&___motionBlur_10), value);
	}

	inline static int32_t get_offset_of_eyeAdaptation_11() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___eyeAdaptation_11)); }
	inline EyeAdaptationModel_t1ACCFD330F4AC0B18055B102CB33E568F6354255 * get_eyeAdaptation_11() const { return ___eyeAdaptation_11; }
	inline EyeAdaptationModel_t1ACCFD330F4AC0B18055B102CB33E568F6354255 ** get_address_of_eyeAdaptation_11() { return &___eyeAdaptation_11; }
	inline void set_eyeAdaptation_11(EyeAdaptationModel_t1ACCFD330F4AC0B18055B102CB33E568F6354255 * value)
	{
		___eyeAdaptation_11 = value;
		Il2CppCodeGenWriteBarrier((&___eyeAdaptation_11), value);
	}

	inline static int32_t get_offset_of_bloom_12() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___bloom_12)); }
	inline BloomModel_tE92443526105DCFC1CBCCC5693C46569B7C15FC3 * get_bloom_12() const { return ___bloom_12; }
	inline BloomModel_tE92443526105DCFC1CBCCC5693C46569B7C15FC3 ** get_address_of_bloom_12() { return &___bloom_12; }
	inline void set_bloom_12(BloomModel_tE92443526105DCFC1CBCCC5693C46569B7C15FC3 * value)
	{
		___bloom_12 = value;
		Il2CppCodeGenWriteBarrier((&___bloom_12), value);
	}

	inline static int32_t get_offset_of_colorGrading_13() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___colorGrading_13)); }
	inline ColorGradingModel_tA35650888B77D10DAB148BD56BB3CEC13C114F89 * get_colorGrading_13() const { return ___colorGrading_13; }
	inline ColorGradingModel_tA35650888B77D10DAB148BD56BB3CEC13C114F89 ** get_address_of_colorGrading_13() { return &___colorGrading_13; }
	inline void set_colorGrading_13(ColorGradingModel_tA35650888B77D10DAB148BD56BB3CEC13C114F89 * value)
	{
		___colorGrading_13 = value;
		Il2CppCodeGenWriteBarrier((&___colorGrading_13), value);
	}

	inline static int32_t get_offset_of_userLut_14() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___userLut_14)); }
	inline UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * get_userLut_14() const { return ___userLut_14; }
	inline UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 ** get_address_of_userLut_14() { return &___userLut_14; }
	inline void set_userLut_14(UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3 * value)
	{
		___userLut_14 = value;
		Il2CppCodeGenWriteBarrier((&___userLut_14), value);
	}

	inline static int32_t get_offset_of_chromaticAberration_15() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___chromaticAberration_15)); }
	inline ChromaticAberrationModel_tC130D625088CD9AD6FC98DD5889D62FB32D26B9A * get_chromaticAberration_15() const { return ___chromaticAberration_15; }
	inline ChromaticAberrationModel_tC130D625088CD9AD6FC98DD5889D62FB32D26B9A ** get_address_of_chromaticAberration_15() { return &___chromaticAberration_15; }
	inline void set_chromaticAberration_15(ChromaticAberrationModel_tC130D625088CD9AD6FC98DD5889D62FB32D26B9A * value)
	{
		___chromaticAberration_15 = value;
		Il2CppCodeGenWriteBarrier((&___chromaticAberration_15), value);
	}

	inline static int32_t get_offset_of_grain_16() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___grain_16)); }
	inline GrainModel_t9E9F9606895937388BD98DDBD0C12D33D820517A * get_grain_16() const { return ___grain_16; }
	inline GrainModel_t9E9F9606895937388BD98DDBD0C12D33D820517A ** get_address_of_grain_16() { return &___grain_16; }
	inline void set_grain_16(GrainModel_t9E9F9606895937388BD98DDBD0C12D33D820517A * value)
	{
		___grain_16 = value;
		Il2CppCodeGenWriteBarrier((&___grain_16), value);
	}

	inline static int32_t get_offset_of_vignette_17() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___vignette_17)); }
	inline VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * get_vignette_17() const { return ___vignette_17; }
	inline VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 ** get_address_of_vignette_17() { return &___vignette_17; }
	inline void set_vignette_17(VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968 * value)
	{
		___vignette_17 = value;
		Il2CppCodeGenWriteBarrier((&___vignette_17), value);
	}

	inline static int32_t get_offset_of_dithering_18() { return static_cast<int32_t>(offsetof(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F, ___dithering_18)); }
	inline DitheringModel_t563302E6CCA426980051A9DD4BE43D907032077F * get_dithering_18() const { return ___dithering_18; }
	inline DitheringModel_t563302E6CCA426980051A9DD4BE43D907032077F ** get_address_of_dithering_18() { return &___dithering_18; }
	inline void set_dithering_18(DitheringModel_t563302E6CCA426980051A9DD4BE43D907032077F * value)
	{
		___dithering_18 = value;
		Il2CppCodeGenWriteBarrier((&___dithering_18), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSINGPROFILE_TDDAC51472A60B9B12D350E7635B49687A06A327F_H
#ifndef SETTINGS_TEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4_H
#define SETTINGS_TEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ScreenSpaceReflectionModel/Settings
struct  Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4 
{
public:
	// UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ReflectionSettings UnityEngine.PostProcessing.ScreenSpaceReflectionModel/Settings::reflection
	ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C  ___reflection_0;
	// UnityEngine.PostProcessing.ScreenSpaceReflectionModel/IntensitySettings UnityEngine.PostProcessing.ScreenSpaceReflectionModel/Settings::intensity
	IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087  ___intensity_1;
	// UnityEngine.PostProcessing.ScreenSpaceReflectionModel/ScreenEdgeMask UnityEngine.PostProcessing.ScreenSpaceReflectionModel/Settings::screenEdgeMask
	ScreenEdgeMask_t94FB1CC384B7C414838A714400DF33EE0F26C468  ___screenEdgeMask_2;

public:
	inline static int32_t get_offset_of_reflection_0() { return static_cast<int32_t>(offsetof(Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4, ___reflection_0)); }
	inline ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C  get_reflection_0() const { return ___reflection_0; }
	inline ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C * get_address_of_reflection_0() { return &___reflection_0; }
	inline void set_reflection_0(ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C  value)
	{
		___reflection_0 = value;
	}

	inline static int32_t get_offset_of_intensity_1() { return static_cast<int32_t>(offsetof(Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4, ___intensity_1)); }
	inline IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087  get_intensity_1() const { return ___intensity_1; }
	inline IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087 * get_address_of_intensity_1() { return &___intensity_1; }
	inline void set_intensity_1(IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087  value)
	{
		___intensity_1 = value;
	}

	inline static int32_t get_offset_of_screenEdgeMask_2() { return static_cast<int32_t>(offsetof(Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4, ___screenEdgeMask_2)); }
	inline ScreenEdgeMask_t94FB1CC384B7C414838A714400DF33EE0F26C468  get_screenEdgeMask_2() const { return ___screenEdgeMask_2; }
	inline ScreenEdgeMask_t94FB1CC384B7C414838A714400DF33EE0F26C468 * get_address_of_screenEdgeMask_2() { return &___screenEdgeMask_2; }
	inline void set_screenEdgeMask_2(ScreenEdgeMask_t94FB1CC384B7C414838A714400DF33EE0F26C468  value)
	{
		___screenEdgeMask_2 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
// Native definition for P/Invoke marshalling of UnityEngine.PostProcessing.ScreenSpaceReflectionModel/Settings
struct Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4_marshaled_pinvoke
{
	ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C_marshaled_pinvoke ___reflection_0;
	IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087  ___intensity_1;
	ScreenEdgeMask_t94FB1CC384B7C414838A714400DF33EE0F26C468  ___screenEdgeMask_2;
};
// Native definition for COM marshalling of UnityEngine.PostProcessing.ScreenSpaceReflectionModel/Settings
struct Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4_marshaled_com
{
	ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C_marshaled_com ___reflection_0;
	IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087  ___intensity_1;
	ScreenEdgeMask_t94FB1CC384B7C414838A714400DF33EE0F26C468  ___screenEdgeMask_2;
};
#endif // SETTINGS_TEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4_H
#ifndef VIGNETTEMODEL_T9F560B811D67D63F69CCF9336093DBAA7A62A968_H
#define VIGNETTEMODEL_T9F560B811D67D63F69CCF9336093DBAA7A62A968_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.VignetteModel
struct  VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968  : public PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A
{
public:
	// UnityEngine.PostProcessing.VignetteModel/Settings UnityEngine.PostProcessing.VignetteModel::m_Settings
	Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  ___m_Settings_1;

public:
	inline static int32_t get_offset_of_m_Settings_1() { return static_cast<int32_t>(offsetof(VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968, ___m_Settings_1)); }
	inline Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  get_m_Settings_1() const { return ___m_Settings_1; }
	inline Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C * get_address_of_m_Settings_1() { return &___m_Settings_1; }
	inline void set_m_Settings_1(Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C  value)
	{
		___m_Settings_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // VIGNETTEMODEL_T9F560B811D67D63F69CCF9336093DBAA7A62A968_H
#ifndef MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#define MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.MonoBehaviour
struct  MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429  : public Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8
{
public:

public:
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // MONOBEHAVIOUR_T4A60845CF505405AF8BE8C61CC07F75CADEF6429_H
#ifndef COLORGRADINGMODEL_TA35650888B77D10DAB148BD56BB3CEC13C114F89_H
#define COLORGRADINGMODEL_TA35650888B77D10DAB148BD56BB3CEC13C114F89_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ColorGradingModel
struct  ColorGradingModel_tA35650888B77D10DAB148BD56BB3CEC13C114F89  : public PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A
{
public:
	// UnityEngine.PostProcessing.ColorGradingModel/Settings UnityEngine.PostProcessing.ColorGradingModel::m_Settings
	Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A  ___m_Settings_1;
	// System.Boolean UnityEngine.PostProcessing.ColorGradingModel::<isDirty>k__BackingField
	bool ___U3CisDirtyU3Ek__BackingField_2;
	// UnityEngine.RenderTexture UnityEngine.PostProcessing.ColorGradingModel::<bakedLut>k__BackingField
	RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * ___U3CbakedLutU3Ek__BackingField_3;

public:
	inline static int32_t get_offset_of_m_Settings_1() { return static_cast<int32_t>(offsetof(ColorGradingModel_tA35650888B77D10DAB148BD56BB3CEC13C114F89, ___m_Settings_1)); }
	inline Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A  get_m_Settings_1() const { return ___m_Settings_1; }
	inline Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A * get_address_of_m_Settings_1() { return &___m_Settings_1; }
	inline void set_m_Settings_1(Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A  value)
	{
		___m_Settings_1 = value;
	}

	inline static int32_t get_offset_of_U3CisDirtyU3Ek__BackingField_2() { return static_cast<int32_t>(offsetof(ColorGradingModel_tA35650888B77D10DAB148BD56BB3CEC13C114F89, ___U3CisDirtyU3Ek__BackingField_2)); }
	inline bool get_U3CisDirtyU3Ek__BackingField_2() const { return ___U3CisDirtyU3Ek__BackingField_2; }
	inline bool* get_address_of_U3CisDirtyU3Ek__BackingField_2() { return &___U3CisDirtyU3Ek__BackingField_2; }
	inline void set_U3CisDirtyU3Ek__BackingField_2(bool value)
	{
		___U3CisDirtyU3Ek__BackingField_2 = value;
	}

	inline static int32_t get_offset_of_U3CbakedLutU3Ek__BackingField_3() { return static_cast<int32_t>(offsetof(ColorGradingModel_tA35650888B77D10DAB148BD56BB3CEC13C114F89, ___U3CbakedLutU3Ek__BackingField_3)); }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * get_U3CbakedLutU3Ek__BackingField_3() const { return ___U3CbakedLutU3Ek__BackingField_3; }
	inline RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 ** get_address_of_U3CbakedLutU3Ek__BackingField_3() { return &___U3CbakedLutU3Ek__BackingField_3; }
	inline void set_U3CbakedLutU3Ek__BackingField_3(RenderTexture_tBC47D853E3DA6511CD6C49DBF78D47B890FCD2F6 * value)
	{
		___U3CbakedLutU3Ek__BackingField_3 = value;
		Il2CppCodeGenWriteBarrier((&___U3CbakedLutU3Ek__BackingField_3), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // COLORGRADINGMODEL_TA35650888B77D10DAB148BD56BB3CEC13C114F89_H
#ifndef SCREENSPACEREFLECTIONMODEL_T05FF878FC8651BE6F59BC62D0167970B047A0A82_H
#define SCREENSPACEREFLECTIONMODEL_T05FF878FC8651BE6F59BC62D0167970B047A0A82_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.ScreenSpaceReflectionModel
struct  ScreenSpaceReflectionModel_t05FF878FC8651BE6F59BC62D0167970B047A0A82  : public PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A
{
public:
	// UnityEngine.PostProcessing.ScreenSpaceReflectionModel/Settings UnityEngine.PostProcessing.ScreenSpaceReflectionModel::m_Settings
	Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4  ___m_Settings_1;

public:
	inline static int32_t get_offset_of_m_Settings_1() { return static_cast<int32_t>(offsetof(ScreenSpaceReflectionModel_t05FF878FC8651BE6F59BC62D0167970B047A0A82, ___m_Settings_1)); }
	inline Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4  get_m_Settings_1() const { return ___m_Settings_1; }
	inline Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4 * get_address_of_m_Settings_1() { return &___m_Settings_1; }
	inline void set_m_Settings_1(Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4  value)
	{
		___m_Settings_1 = value;
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // SCREENSPACEREFLECTIONMODEL_T05FF878FC8651BE6F59BC62D0167970B047A0A82_H
#ifndef POSTPROCESSINGBEHAVIOUR_T845414E0C0D9C84A787F25EB881C1D8990CC1469_H
#define POSTPROCESSINGBEHAVIOUR_T845414E0C0D9C84A787F25EB881C1D8990CC1469_H
#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// UnityEngine.PostProcessing.PostProcessingBehaviour
struct  PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.PostProcessing.PostProcessingProfile UnityEngine.PostProcessing.PostProcessingBehaviour::profile
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F * ___profile_4;
	// System.Func`2<UnityEngine.Vector2,UnityEngine.Matrix4x4> UnityEngine.PostProcessing.PostProcessingBehaviour::jitteredMatrixFunc
	Func_2_tA54608942A814FAFFEB1EDED9D6C2457F3A9CBE6 * ___jitteredMatrixFunc_5;
	// System.Collections.Generic.Dictionary`2<System.Type,System.Collections.Generic.KeyValuePair`2<UnityEngine.Rendering.CameraEvent,UnityEngine.Rendering.CommandBuffer>> UnityEngine.PostProcessing.PostProcessingBehaviour::m_CommandBuffers
	Dictionary_2_t3EA5986628F6FACCBE89BAE776057ACD38E26941 * ___m_CommandBuffers_6;
	// System.Collections.Generic.List`1<UnityEngine.PostProcessing.PostProcessingComponentBase> UnityEngine.PostProcessing.PostProcessingBehaviour::m_Components
	List_1_tDD5D4A93EE80EDC5A199B8CBB3810E0C1828747C * ___m_Components_7;
	// System.Collections.Generic.Dictionary`2<UnityEngine.PostProcessing.PostProcessingComponentBase,System.Boolean> UnityEngine.PostProcessing.PostProcessingBehaviour::m_ComponentStates
	Dictionary_2_t8D598EF753E89FFF2347CC60824D3641B107B975 * ___m_ComponentStates_8;
	// UnityEngine.PostProcessing.MaterialFactory UnityEngine.PostProcessing.PostProcessingBehaviour::m_MaterialFactory
	MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05 * ___m_MaterialFactory_9;
	// UnityEngine.PostProcessing.RenderTextureFactory UnityEngine.PostProcessing.PostProcessingBehaviour::m_RenderTextureFactory
	RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236 * ___m_RenderTextureFactory_10;
	// UnityEngine.PostProcessing.PostProcessingContext UnityEngine.PostProcessing.PostProcessingBehaviour::m_Context
	PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * ___m_Context_11;
	// UnityEngine.Camera UnityEngine.PostProcessing.PostProcessingBehaviour::m_Camera
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___m_Camera_12;
	// UnityEngine.PostProcessing.PostProcessingProfile UnityEngine.PostProcessing.PostProcessingBehaviour::m_PreviousProfile
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F * ___m_PreviousProfile_13;
	// System.Boolean UnityEngine.PostProcessing.PostProcessingBehaviour::m_RenderingInSceneView
	bool ___m_RenderingInSceneView_14;
	// UnityEngine.PostProcessing.BuiltinDebugViewsComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_DebugViews
	BuiltinDebugViewsComponent_t87723A30E7942CB092EAD35327CA11678261FF78 * ___m_DebugViews_15;
	// UnityEngine.PostProcessing.AmbientOcclusionComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_AmbientOcclusion
	AmbientOcclusionComponent_t81193D762EEB87BEFF67DB596A08B6930340BA8E * ___m_AmbientOcclusion_16;
	// UnityEngine.PostProcessing.ScreenSpaceReflectionComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_ScreenSpaceReflection
	ScreenSpaceReflectionComponent_t785FC5967CACB503C8EFDBFF1C9D67710D9E43C8 * ___m_ScreenSpaceReflection_17;
	// UnityEngine.PostProcessing.FogComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_FogComponent
	FogComponent_t9842887E79FF485E76210221A8C71F64DF34C9D4 * ___m_FogComponent_18;
	// UnityEngine.PostProcessing.MotionBlurComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_MotionBlur
	MotionBlurComponent_t09EA322668565E8405B27EB4B8953068B27AA8AE * ___m_MotionBlur_19;
	// UnityEngine.PostProcessing.TaaComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_Taa
	TaaComponent_t6C3D9F056CFBADD9316CFEA0105287F096F5BE65 * ___m_Taa_20;
	// UnityEngine.PostProcessing.EyeAdaptationComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_EyeAdaptation
	EyeAdaptationComponent_tBB4AB82FAD9CB6A10B01F41A73E35A2FB9B2FE88 * ___m_EyeAdaptation_21;
	// UnityEngine.PostProcessing.DepthOfFieldComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_DepthOfField
	DepthOfFieldComponent_tE324DC55E88F64151539A068D089390FD90885F7 * ___m_DepthOfField_22;
	// UnityEngine.PostProcessing.BloomComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_Bloom
	BloomComponent_t7C69968D6D52293BB28214D29BF6DE4FE6DC431E * ___m_Bloom_23;
	// UnityEngine.PostProcessing.ChromaticAberrationComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_ChromaticAberration
	ChromaticAberrationComponent_tB1493E31E21AF2FBD5D5314EFE4E1E38680E8ACD * ___m_ChromaticAberration_24;
	// UnityEngine.PostProcessing.ColorGradingComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_ColorGrading
	ColorGradingComponent_t3C9E6F9B43DCB041A15CD6439143D3732BBFF7DA * ___m_ColorGrading_25;
	// UnityEngine.PostProcessing.UserLutComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_UserLut
	UserLutComponent_t005DFBA977CDDBE18D9A45A9CD7BA3081F16FBFE * ___m_UserLut_26;
	// UnityEngine.PostProcessing.GrainComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_Grain
	GrainComponent_t860BB92FF09582F05AA7E0F5BA8C93D2D89CEF20 * ___m_Grain_27;
	// UnityEngine.PostProcessing.VignetteComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_Vignette
	VignetteComponent_t8DF40FEBD25DA993440BAE1B4306153A285834A1 * ___m_Vignette_28;
	// UnityEngine.PostProcessing.DitheringComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_Dithering
	DitheringComponent_tD2CC455BCA16DB5143C280EEF5FCB135BFA9EF2F * ___m_Dithering_29;
	// UnityEngine.PostProcessing.FxaaComponent UnityEngine.PostProcessing.PostProcessingBehaviour::m_Fxaa
	FxaaComponent_t6192F903F2E99176AF962CBAB4D9A79102647F03 * ___m_Fxaa_30;
	// System.Collections.Generic.List`1<UnityEngine.PostProcessing.PostProcessingComponentBase> UnityEngine.PostProcessing.PostProcessingBehaviour::m_ComponentsToEnable
	List_1_tDD5D4A93EE80EDC5A199B8CBB3810E0C1828747C * ___m_ComponentsToEnable_31;
	// System.Collections.Generic.List`1<UnityEngine.PostProcessing.PostProcessingComponentBase> UnityEngine.PostProcessing.PostProcessingBehaviour::m_ComponentsToDisable
	List_1_tDD5D4A93EE80EDC5A199B8CBB3810E0C1828747C * ___m_ComponentsToDisable_32;

public:
	inline static int32_t get_offset_of_profile_4() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___profile_4)); }
	inline PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F * get_profile_4() const { return ___profile_4; }
	inline PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F ** get_address_of_profile_4() { return &___profile_4; }
	inline void set_profile_4(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F * value)
	{
		___profile_4 = value;
		Il2CppCodeGenWriteBarrier((&___profile_4), value);
	}

	inline static int32_t get_offset_of_jitteredMatrixFunc_5() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___jitteredMatrixFunc_5)); }
	inline Func_2_tA54608942A814FAFFEB1EDED9D6C2457F3A9CBE6 * get_jitteredMatrixFunc_5() const { return ___jitteredMatrixFunc_5; }
	inline Func_2_tA54608942A814FAFFEB1EDED9D6C2457F3A9CBE6 ** get_address_of_jitteredMatrixFunc_5() { return &___jitteredMatrixFunc_5; }
	inline void set_jitteredMatrixFunc_5(Func_2_tA54608942A814FAFFEB1EDED9D6C2457F3A9CBE6 * value)
	{
		___jitteredMatrixFunc_5 = value;
		Il2CppCodeGenWriteBarrier((&___jitteredMatrixFunc_5), value);
	}

	inline static int32_t get_offset_of_m_CommandBuffers_6() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_CommandBuffers_6)); }
	inline Dictionary_2_t3EA5986628F6FACCBE89BAE776057ACD38E26941 * get_m_CommandBuffers_6() const { return ___m_CommandBuffers_6; }
	inline Dictionary_2_t3EA5986628F6FACCBE89BAE776057ACD38E26941 ** get_address_of_m_CommandBuffers_6() { return &___m_CommandBuffers_6; }
	inline void set_m_CommandBuffers_6(Dictionary_2_t3EA5986628F6FACCBE89BAE776057ACD38E26941 * value)
	{
		___m_CommandBuffers_6 = value;
		Il2CppCodeGenWriteBarrier((&___m_CommandBuffers_6), value);
	}

	inline static int32_t get_offset_of_m_Components_7() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_Components_7)); }
	inline List_1_tDD5D4A93EE80EDC5A199B8CBB3810E0C1828747C * get_m_Components_7() const { return ___m_Components_7; }
	inline List_1_tDD5D4A93EE80EDC5A199B8CBB3810E0C1828747C ** get_address_of_m_Components_7() { return &___m_Components_7; }
	inline void set_m_Components_7(List_1_tDD5D4A93EE80EDC5A199B8CBB3810E0C1828747C * value)
	{
		___m_Components_7 = value;
		Il2CppCodeGenWriteBarrier((&___m_Components_7), value);
	}

	inline static int32_t get_offset_of_m_ComponentStates_8() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_ComponentStates_8)); }
	inline Dictionary_2_t8D598EF753E89FFF2347CC60824D3641B107B975 * get_m_ComponentStates_8() const { return ___m_ComponentStates_8; }
	inline Dictionary_2_t8D598EF753E89FFF2347CC60824D3641B107B975 ** get_address_of_m_ComponentStates_8() { return &___m_ComponentStates_8; }
	inline void set_m_ComponentStates_8(Dictionary_2_t8D598EF753E89FFF2347CC60824D3641B107B975 * value)
	{
		___m_ComponentStates_8 = value;
		Il2CppCodeGenWriteBarrier((&___m_ComponentStates_8), value);
	}

	inline static int32_t get_offset_of_m_MaterialFactory_9() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_MaterialFactory_9)); }
	inline MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05 * get_m_MaterialFactory_9() const { return ___m_MaterialFactory_9; }
	inline MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05 ** get_address_of_m_MaterialFactory_9() { return &___m_MaterialFactory_9; }
	inline void set_m_MaterialFactory_9(MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05 * value)
	{
		___m_MaterialFactory_9 = value;
		Il2CppCodeGenWriteBarrier((&___m_MaterialFactory_9), value);
	}

	inline static int32_t get_offset_of_m_RenderTextureFactory_10() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_RenderTextureFactory_10)); }
	inline RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236 * get_m_RenderTextureFactory_10() const { return ___m_RenderTextureFactory_10; }
	inline RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236 ** get_address_of_m_RenderTextureFactory_10() { return &___m_RenderTextureFactory_10; }
	inline void set_m_RenderTextureFactory_10(RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236 * value)
	{
		___m_RenderTextureFactory_10 = value;
		Il2CppCodeGenWriteBarrier((&___m_RenderTextureFactory_10), value);
	}

	inline static int32_t get_offset_of_m_Context_11() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_Context_11)); }
	inline PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * get_m_Context_11() const { return ___m_Context_11; }
	inline PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 ** get_address_of_m_Context_11() { return &___m_Context_11; }
	inline void set_m_Context_11(PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7 * value)
	{
		___m_Context_11 = value;
		Il2CppCodeGenWriteBarrier((&___m_Context_11), value);
	}

	inline static int32_t get_offset_of_m_Camera_12() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_Camera_12)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_m_Camera_12() const { return ___m_Camera_12; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_m_Camera_12() { return &___m_Camera_12; }
	inline void set_m_Camera_12(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___m_Camera_12 = value;
		Il2CppCodeGenWriteBarrier((&___m_Camera_12), value);
	}

	inline static int32_t get_offset_of_m_PreviousProfile_13() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_PreviousProfile_13)); }
	inline PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F * get_m_PreviousProfile_13() const { return ___m_PreviousProfile_13; }
	inline PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F ** get_address_of_m_PreviousProfile_13() { return &___m_PreviousProfile_13; }
	inline void set_m_PreviousProfile_13(PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F * value)
	{
		___m_PreviousProfile_13 = value;
		Il2CppCodeGenWriteBarrier((&___m_PreviousProfile_13), value);
	}

	inline static int32_t get_offset_of_m_RenderingInSceneView_14() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_RenderingInSceneView_14)); }
	inline bool get_m_RenderingInSceneView_14() const { return ___m_RenderingInSceneView_14; }
	inline bool* get_address_of_m_RenderingInSceneView_14() { return &___m_RenderingInSceneView_14; }
	inline void set_m_RenderingInSceneView_14(bool value)
	{
		___m_RenderingInSceneView_14 = value;
	}

	inline static int32_t get_offset_of_m_DebugViews_15() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_DebugViews_15)); }
	inline BuiltinDebugViewsComponent_t87723A30E7942CB092EAD35327CA11678261FF78 * get_m_DebugViews_15() const { return ___m_DebugViews_15; }
	inline BuiltinDebugViewsComponent_t87723A30E7942CB092EAD35327CA11678261FF78 ** get_address_of_m_DebugViews_15() { return &___m_DebugViews_15; }
	inline void set_m_DebugViews_15(BuiltinDebugViewsComponent_t87723A30E7942CB092EAD35327CA11678261FF78 * value)
	{
		___m_DebugViews_15 = value;
		Il2CppCodeGenWriteBarrier((&___m_DebugViews_15), value);
	}

	inline static int32_t get_offset_of_m_AmbientOcclusion_16() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_AmbientOcclusion_16)); }
	inline AmbientOcclusionComponent_t81193D762EEB87BEFF67DB596A08B6930340BA8E * get_m_AmbientOcclusion_16() const { return ___m_AmbientOcclusion_16; }
	inline AmbientOcclusionComponent_t81193D762EEB87BEFF67DB596A08B6930340BA8E ** get_address_of_m_AmbientOcclusion_16() { return &___m_AmbientOcclusion_16; }
	inline void set_m_AmbientOcclusion_16(AmbientOcclusionComponent_t81193D762EEB87BEFF67DB596A08B6930340BA8E * value)
	{
		___m_AmbientOcclusion_16 = value;
		Il2CppCodeGenWriteBarrier((&___m_AmbientOcclusion_16), value);
	}

	inline static int32_t get_offset_of_m_ScreenSpaceReflection_17() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_ScreenSpaceReflection_17)); }
	inline ScreenSpaceReflectionComponent_t785FC5967CACB503C8EFDBFF1C9D67710D9E43C8 * get_m_ScreenSpaceReflection_17() const { return ___m_ScreenSpaceReflection_17; }
	inline ScreenSpaceReflectionComponent_t785FC5967CACB503C8EFDBFF1C9D67710D9E43C8 ** get_address_of_m_ScreenSpaceReflection_17() { return &___m_ScreenSpaceReflection_17; }
	inline void set_m_ScreenSpaceReflection_17(ScreenSpaceReflectionComponent_t785FC5967CACB503C8EFDBFF1C9D67710D9E43C8 * value)
	{
		___m_ScreenSpaceReflection_17 = value;
		Il2CppCodeGenWriteBarrier((&___m_ScreenSpaceReflection_17), value);
	}

	inline static int32_t get_offset_of_m_FogComponent_18() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_FogComponent_18)); }
	inline FogComponent_t9842887E79FF485E76210221A8C71F64DF34C9D4 * get_m_FogComponent_18() const { return ___m_FogComponent_18; }
	inline FogComponent_t9842887E79FF485E76210221A8C71F64DF34C9D4 ** get_address_of_m_FogComponent_18() { return &___m_FogComponent_18; }
	inline void set_m_FogComponent_18(FogComponent_t9842887E79FF485E76210221A8C71F64DF34C9D4 * value)
	{
		___m_FogComponent_18 = value;
		Il2CppCodeGenWriteBarrier((&___m_FogComponent_18), value);
	}

	inline static int32_t get_offset_of_m_MotionBlur_19() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_MotionBlur_19)); }
	inline MotionBlurComponent_t09EA322668565E8405B27EB4B8953068B27AA8AE * get_m_MotionBlur_19() const { return ___m_MotionBlur_19; }
	inline MotionBlurComponent_t09EA322668565E8405B27EB4B8953068B27AA8AE ** get_address_of_m_MotionBlur_19() { return &___m_MotionBlur_19; }
	inline void set_m_MotionBlur_19(MotionBlurComponent_t09EA322668565E8405B27EB4B8953068B27AA8AE * value)
	{
		___m_MotionBlur_19 = value;
		Il2CppCodeGenWriteBarrier((&___m_MotionBlur_19), value);
	}

	inline static int32_t get_offset_of_m_Taa_20() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_Taa_20)); }
	inline TaaComponent_t6C3D9F056CFBADD9316CFEA0105287F096F5BE65 * get_m_Taa_20() const { return ___m_Taa_20; }
	inline TaaComponent_t6C3D9F056CFBADD9316CFEA0105287F096F5BE65 ** get_address_of_m_Taa_20() { return &___m_Taa_20; }
	inline void set_m_Taa_20(TaaComponent_t6C3D9F056CFBADD9316CFEA0105287F096F5BE65 * value)
	{
		___m_Taa_20 = value;
		Il2CppCodeGenWriteBarrier((&___m_Taa_20), value);
	}

	inline static int32_t get_offset_of_m_EyeAdaptation_21() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_EyeAdaptation_21)); }
	inline EyeAdaptationComponent_tBB4AB82FAD9CB6A10B01F41A73E35A2FB9B2FE88 * get_m_EyeAdaptation_21() const { return ___m_EyeAdaptation_21; }
	inline EyeAdaptationComponent_tBB4AB82FAD9CB6A10B01F41A73E35A2FB9B2FE88 ** get_address_of_m_EyeAdaptation_21() { return &___m_EyeAdaptation_21; }
	inline void set_m_EyeAdaptation_21(EyeAdaptationComponent_tBB4AB82FAD9CB6A10B01F41A73E35A2FB9B2FE88 * value)
	{
		___m_EyeAdaptation_21 = value;
		Il2CppCodeGenWriteBarrier((&___m_EyeAdaptation_21), value);
	}

	inline static int32_t get_offset_of_m_DepthOfField_22() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_DepthOfField_22)); }
	inline DepthOfFieldComponent_tE324DC55E88F64151539A068D089390FD90885F7 * get_m_DepthOfField_22() const { return ___m_DepthOfField_22; }
	inline DepthOfFieldComponent_tE324DC55E88F64151539A068D089390FD90885F7 ** get_address_of_m_DepthOfField_22() { return &___m_DepthOfField_22; }
	inline void set_m_DepthOfField_22(DepthOfFieldComponent_tE324DC55E88F64151539A068D089390FD90885F7 * value)
	{
		___m_DepthOfField_22 = value;
		Il2CppCodeGenWriteBarrier((&___m_DepthOfField_22), value);
	}

	inline static int32_t get_offset_of_m_Bloom_23() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_Bloom_23)); }
	inline BloomComponent_t7C69968D6D52293BB28214D29BF6DE4FE6DC431E * get_m_Bloom_23() const { return ___m_Bloom_23; }
	inline BloomComponent_t7C69968D6D52293BB28214D29BF6DE4FE6DC431E ** get_address_of_m_Bloom_23() { return &___m_Bloom_23; }
	inline void set_m_Bloom_23(BloomComponent_t7C69968D6D52293BB28214D29BF6DE4FE6DC431E * value)
	{
		___m_Bloom_23 = value;
		Il2CppCodeGenWriteBarrier((&___m_Bloom_23), value);
	}

	inline static int32_t get_offset_of_m_ChromaticAberration_24() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_ChromaticAberration_24)); }
	inline ChromaticAberrationComponent_tB1493E31E21AF2FBD5D5314EFE4E1E38680E8ACD * get_m_ChromaticAberration_24() const { return ___m_ChromaticAberration_24; }
	inline ChromaticAberrationComponent_tB1493E31E21AF2FBD5D5314EFE4E1E38680E8ACD ** get_address_of_m_ChromaticAberration_24() { return &___m_ChromaticAberration_24; }
	inline void set_m_ChromaticAberration_24(ChromaticAberrationComponent_tB1493E31E21AF2FBD5D5314EFE4E1E38680E8ACD * value)
	{
		___m_ChromaticAberration_24 = value;
		Il2CppCodeGenWriteBarrier((&___m_ChromaticAberration_24), value);
	}

	inline static int32_t get_offset_of_m_ColorGrading_25() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_ColorGrading_25)); }
	inline ColorGradingComponent_t3C9E6F9B43DCB041A15CD6439143D3732BBFF7DA * get_m_ColorGrading_25() const { return ___m_ColorGrading_25; }
	inline ColorGradingComponent_t3C9E6F9B43DCB041A15CD6439143D3732BBFF7DA ** get_address_of_m_ColorGrading_25() { return &___m_ColorGrading_25; }
	inline void set_m_ColorGrading_25(ColorGradingComponent_t3C9E6F9B43DCB041A15CD6439143D3732BBFF7DA * value)
	{
		___m_ColorGrading_25 = value;
		Il2CppCodeGenWriteBarrier((&___m_ColorGrading_25), value);
	}

	inline static int32_t get_offset_of_m_UserLut_26() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_UserLut_26)); }
	inline UserLutComponent_t005DFBA977CDDBE18D9A45A9CD7BA3081F16FBFE * get_m_UserLut_26() const { return ___m_UserLut_26; }
	inline UserLutComponent_t005DFBA977CDDBE18D9A45A9CD7BA3081F16FBFE ** get_address_of_m_UserLut_26() { return &___m_UserLut_26; }
	inline void set_m_UserLut_26(UserLutComponent_t005DFBA977CDDBE18D9A45A9CD7BA3081F16FBFE * value)
	{
		___m_UserLut_26 = value;
		Il2CppCodeGenWriteBarrier((&___m_UserLut_26), value);
	}

	inline static int32_t get_offset_of_m_Grain_27() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_Grain_27)); }
	inline GrainComponent_t860BB92FF09582F05AA7E0F5BA8C93D2D89CEF20 * get_m_Grain_27() const { return ___m_Grain_27; }
	inline GrainComponent_t860BB92FF09582F05AA7E0F5BA8C93D2D89CEF20 ** get_address_of_m_Grain_27() { return &___m_Grain_27; }
	inline void set_m_Grain_27(GrainComponent_t860BB92FF09582F05AA7E0F5BA8C93D2D89CEF20 * value)
	{
		___m_Grain_27 = value;
		Il2CppCodeGenWriteBarrier((&___m_Grain_27), value);
	}

	inline static int32_t get_offset_of_m_Vignette_28() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_Vignette_28)); }
	inline VignetteComponent_t8DF40FEBD25DA993440BAE1B4306153A285834A1 * get_m_Vignette_28() const { return ___m_Vignette_28; }
	inline VignetteComponent_t8DF40FEBD25DA993440BAE1B4306153A285834A1 ** get_address_of_m_Vignette_28() { return &___m_Vignette_28; }
	inline void set_m_Vignette_28(VignetteComponent_t8DF40FEBD25DA993440BAE1B4306153A285834A1 * value)
	{
		___m_Vignette_28 = value;
		Il2CppCodeGenWriteBarrier((&___m_Vignette_28), value);
	}

	inline static int32_t get_offset_of_m_Dithering_29() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_Dithering_29)); }
	inline DitheringComponent_tD2CC455BCA16DB5143C280EEF5FCB135BFA9EF2F * get_m_Dithering_29() const { return ___m_Dithering_29; }
	inline DitheringComponent_tD2CC455BCA16DB5143C280EEF5FCB135BFA9EF2F ** get_address_of_m_Dithering_29() { return &___m_Dithering_29; }
	inline void set_m_Dithering_29(DitheringComponent_tD2CC455BCA16DB5143C280EEF5FCB135BFA9EF2F * value)
	{
		___m_Dithering_29 = value;
		Il2CppCodeGenWriteBarrier((&___m_Dithering_29), value);
	}

	inline static int32_t get_offset_of_m_Fxaa_30() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_Fxaa_30)); }
	inline FxaaComponent_t6192F903F2E99176AF962CBAB4D9A79102647F03 * get_m_Fxaa_30() const { return ___m_Fxaa_30; }
	inline FxaaComponent_t6192F903F2E99176AF962CBAB4D9A79102647F03 ** get_address_of_m_Fxaa_30() { return &___m_Fxaa_30; }
	inline void set_m_Fxaa_30(FxaaComponent_t6192F903F2E99176AF962CBAB4D9A79102647F03 * value)
	{
		___m_Fxaa_30 = value;
		Il2CppCodeGenWriteBarrier((&___m_Fxaa_30), value);
	}

	inline static int32_t get_offset_of_m_ComponentsToEnable_31() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_ComponentsToEnable_31)); }
	inline List_1_tDD5D4A93EE80EDC5A199B8CBB3810E0C1828747C * get_m_ComponentsToEnable_31() const { return ___m_ComponentsToEnable_31; }
	inline List_1_tDD5D4A93EE80EDC5A199B8CBB3810E0C1828747C ** get_address_of_m_ComponentsToEnable_31() { return &___m_ComponentsToEnable_31; }
	inline void set_m_ComponentsToEnable_31(List_1_tDD5D4A93EE80EDC5A199B8CBB3810E0C1828747C * value)
	{
		___m_ComponentsToEnable_31 = value;
		Il2CppCodeGenWriteBarrier((&___m_ComponentsToEnable_31), value);
	}

	inline static int32_t get_offset_of_m_ComponentsToDisable_32() { return static_cast<int32_t>(offsetof(PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469, ___m_ComponentsToDisable_32)); }
	inline List_1_tDD5D4A93EE80EDC5A199B8CBB3810E0C1828747C * get_m_ComponentsToDisable_32() const { return ___m_ComponentsToDisable_32; }
	inline List_1_tDD5D4A93EE80EDC5A199B8CBB3810E0C1828747C ** get_address_of_m_ComponentsToDisable_32() { return &___m_ComponentsToDisable_32; }
	inline void set_m_ComponentsToDisable_32(List_1_tDD5D4A93EE80EDC5A199B8CBB3810E0C1828747C * value)
	{
		___m_ComponentsToDisable_32 = value;
		Il2CppCodeGenWriteBarrier((&___m_ComponentsToDisable_32), value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif
#endif // POSTPROCESSINGBEHAVIOUR_T845414E0C0D9C84A787F25EB881C1D8990CC1469_H





#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2900 = { sizeof (LensDirtSettings_t853B5863231B63C1DDAA5F98E04699597E47137A)+ sizeof (RuntimeObject), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2900[2] = 
{
	LensDirtSettings_t853B5863231B63C1DDAA5F98E04699597E47137A::get_offset_of_texture_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	LensDirtSettings_t853B5863231B63C1DDAA5F98E04699597E47137A::get_offset_of_intensity_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2901 = { sizeof (Settings_tDAF4DB4C944143B285B5CBAF40509B6559800E3A)+ sizeof (RuntimeObject), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2901[2] = 
{
	Settings_tDAF4DB4C944143B285B5CBAF40509B6559800E3A::get_offset_of_bloom_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_tDAF4DB4C944143B285B5CBAF40509B6559800E3A::get_offset_of_lensDirt_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2902 = { sizeof (BuiltinDebugViewsModel_t3895BEF4E3FAA223414BEB50B52AE8E40209040D), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2902[1] = 
{
	BuiltinDebugViewsModel_t3895BEF4E3FAA223414BEB50B52AE8E40209040D::get_offset_of_m_Settings_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2903 = { sizeof (DepthSettings_tC484EB6F5B3327CF16840634323AF5CFFEE126EC)+ sizeof (RuntimeObject), sizeof(DepthSettings_tC484EB6F5B3327CF16840634323AF5CFFEE126EC ), 0, 0 };
extern const int32_t g_FieldOffsetTable2903[1] = 
{
	DepthSettings_tC484EB6F5B3327CF16840634323AF5CFFEE126EC::get_offset_of_scale_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2904 = { sizeof (MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256)+ sizeof (RuntimeObject), sizeof(MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256 ), 0, 0 };
extern const int32_t g_FieldOffsetTable2904[6] = 
{
	MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256::get_offset_of_sourceOpacity_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256::get_offset_of_motionImageOpacity_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256::get_offset_of_motionImageAmplitude_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256::get_offset_of_motionVectorsOpacity_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
	MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256::get_offset_of_motionVectorsResolution_4() + static_cast<int32_t>(sizeof(RuntimeObject)),
	MotionVectorsSettings_t52E092FE390993B7C5006300306ED2C3F942B256::get_offset_of_motionVectorsAmplitude_5() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2905 = { sizeof (Mode_tE6D4BA29442A4ABB76D9ADE04877164873931AB7)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2905[11] = 
{
	Mode_tE6D4BA29442A4ABB76D9ADE04877164873931AB7::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2906 = { sizeof (Settings_t897B8FE3086F458E5E210D35F39B494A88494591)+ sizeof (RuntimeObject), sizeof(Settings_t897B8FE3086F458E5E210D35F39B494A88494591 ), 0, 0 };
extern const int32_t g_FieldOffsetTable2906[3] = 
{
	Settings_t897B8FE3086F458E5E210D35F39B494A88494591::get_offset_of_mode_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t897B8FE3086F458E5E210D35F39B494A88494591::get_offset_of_depth_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t897B8FE3086F458E5E210D35F39B494A88494591::get_offset_of_motionVectors_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2907 = { sizeof (ChromaticAberrationModel_tC130D625088CD9AD6FC98DD5889D62FB32D26B9A), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2907[1] = 
{
	ChromaticAberrationModel_tC130D625088CD9AD6FC98DD5889D62FB32D26B9A::get_offset_of_m_Settings_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2908 = { sizeof (Settings_t3B36530BC44129694D3A136E05855736FAB00743)+ sizeof (RuntimeObject), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2908[2] = 
{
	Settings_t3B36530BC44129694D3A136E05855736FAB00743::get_offset_of_spectralTexture_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t3B36530BC44129694D3A136E05855736FAB00743::get_offset_of_intensity_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2909 = { sizeof (ColorGradingModel_tA35650888B77D10DAB148BD56BB3CEC13C114F89), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2909[3] = 
{
	ColorGradingModel_tA35650888B77D10DAB148BD56BB3CEC13C114F89::get_offset_of_m_Settings_1(),
	ColorGradingModel_tA35650888B77D10DAB148BD56BB3CEC13C114F89::get_offset_of_U3CisDirtyU3Ek__BackingField_2(),
	ColorGradingModel_tA35650888B77D10DAB148BD56BB3CEC13C114F89::get_offset_of_U3CbakedLutU3Ek__BackingField_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2910 = { sizeof (Tonemapper_tB393B8D6ED90C74BC74C860CEE8B3D2374DEE621)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2910[4] = 
{
	Tonemapper_tB393B8D6ED90C74BC74C860CEE8B3D2374DEE621::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2911 = { sizeof (TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC)+ sizeof (RuntimeObject), sizeof(TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC ), 0, 0 };
extern const int32_t g_FieldOffsetTable2911[7] = 
{
	TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC::get_offset_of_tonemapper_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC::get_offset_of_neutralBlackIn_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC::get_offset_of_neutralWhiteIn_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC::get_offset_of_neutralBlackOut_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
	TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC::get_offset_of_neutralWhiteOut_4() + static_cast<int32_t>(sizeof(RuntimeObject)),
	TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC::get_offset_of_neutralWhiteLevel_5() + static_cast<int32_t>(sizeof(RuntimeObject)),
	TonemappingSettings_t6325A1335977835D76781574FA3E47A97B7179DC::get_offset_of_neutralWhiteClip_6() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2912 = { sizeof (BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49)+ sizeof (RuntimeObject), sizeof(BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49 ), 0, 0 };
extern const int32_t g_FieldOffsetTable2912[6] = 
{
	BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49::get_offset_of_postExposure_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49::get_offset_of_temperature_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49::get_offset_of_tint_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49::get_offset_of_hueShift_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
	BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49::get_offset_of_saturation_4() + static_cast<int32_t>(sizeof(RuntimeObject)),
	BasicSettings_t6BDB17237FE91CFD75E4659392E068376014EA49::get_offset_of_contrast_5() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2913 = { sizeof (ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B)+ sizeof (RuntimeObject), sizeof(ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B ), 0, 0 };
extern const int32_t g_FieldOffsetTable2913[4] = 
{
	ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B::get_offset_of_red_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B::get_offset_of_green_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B::get_offset_of_blue_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	ChannelMixerSettings_t431B35AD1976F2AF867DD00D992769BE455DC09B::get_offset_of_currentEditingChannel_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2914 = { sizeof (LogWheelsSettings_t6946B0985F2ECDA5D31B31D9DC70072ED0819EF5)+ sizeof (RuntimeObject), sizeof(LogWheelsSettings_t6946B0985F2ECDA5D31B31D9DC70072ED0819EF5 ), 0, 0 };
extern const int32_t g_FieldOffsetTable2914[3] = 
{
	LogWheelsSettings_t6946B0985F2ECDA5D31B31D9DC70072ED0819EF5::get_offset_of_slope_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	LogWheelsSettings_t6946B0985F2ECDA5D31B31D9DC70072ED0819EF5::get_offset_of_power_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	LogWheelsSettings_t6946B0985F2ECDA5D31B31D9DC70072ED0819EF5::get_offset_of_offset_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2915 = { sizeof (LinearWheelsSettings_tA2E68F6BF46B81203AF36DCB129409CAB51EC704)+ sizeof (RuntimeObject), sizeof(LinearWheelsSettings_tA2E68F6BF46B81203AF36DCB129409CAB51EC704 ), 0, 0 };
extern const int32_t g_FieldOffsetTable2915[3] = 
{
	LinearWheelsSettings_tA2E68F6BF46B81203AF36DCB129409CAB51EC704::get_offset_of_lift_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	LinearWheelsSettings_tA2E68F6BF46B81203AF36DCB129409CAB51EC704::get_offset_of_gamma_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	LinearWheelsSettings_tA2E68F6BF46B81203AF36DCB129409CAB51EC704::get_offset_of_gain_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2916 = { sizeof (ColorWheelMode_tF684466A07AFC545A3148235696DDAFE737CE34E)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2916[3] = 
{
	ColorWheelMode_tF684466A07AFC545A3148235696DDAFE737CE34E::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2917 = { sizeof (ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8)+ sizeof (RuntimeObject), sizeof(ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8 ), 0, 0 };
extern const int32_t g_FieldOffsetTable2917[3] = 
{
	ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8::get_offset_of_mode_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8::get_offset_of_log_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	ColorWheelsSettings_t9C91F8B31A98943530FDFC38F386D98874501EC8::get_offset_of_linear_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2918 = { sizeof (CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E)+ sizeof (RuntimeObject), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2918[13] = 
{
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E::get_offset_of_master_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E::get_offset_of_red_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E::get_offset_of_green_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E::get_offset_of_blue_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E::get_offset_of_hueVShue_4() + static_cast<int32_t>(sizeof(RuntimeObject)),
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E::get_offset_of_hueVSsat_5() + static_cast<int32_t>(sizeof(RuntimeObject)),
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E::get_offset_of_satVSsat_6() + static_cast<int32_t>(sizeof(RuntimeObject)),
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E::get_offset_of_lumVSsat_7() + static_cast<int32_t>(sizeof(RuntimeObject)),
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E::get_offset_of_e_CurrentEditingCurve_8() + static_cast<int32_t>(sizeof(RuntimeObject)),
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E::get_offset_of_e_CurveY_9() + static_cast<int32_t>(sizeof(RuntimeObject)),
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E::get_offset_of_e_CurveR_10() + static_cast<int32_t>(sizeof(RuntimeObject)),
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E::get_offset_of_e_CurveG_11() + static_cast<int32_t>(sizeof(RuntimeObject)),
	CurvesSettings_t1B75302479E162A4CA5A29D18CCD1D46FD6C7A2E::get_offset_of_e_CurveB_12() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2919 = { sizeof (Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A)+ sizeof (RuntimeObject), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2919[5] = 
{
	Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A::get_offset_of_tonemapping_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A::get_offset_of_basic_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A::get_offset_of_channelMixer_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A::get_offset_of_colorWheels_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t48BF09637C1A12D6B94A6E21D32A58B301F6759A::get_offset_of_curves_4() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2920 = { sizeof (DepthOfFieldModel_t467AC9D0D874371D108098B766B99177AE416A76), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2920[1] = 
{
	DepthOfFieldModel_t467AC9D0D874371D108098B766B99177AE416A76::get_offset_of_m_Settings_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2921 = { sizeof (KernelSize_tE92DFA32991EA99967B6FA6A9CA00BC6002B72AD)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2921[5] = 
{
	KernelSize_tE92DFA32991EA99967B6FA6A9CA00BC6002B72AD::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2922 = { sizeof (Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E)+ sizeof (RuntimeObject), sizeof(Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable2922[5] = 
{
	Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E::get_offset_of_focusDistance_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E::get_offset_of_aperture_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E::get_offset_of_focalLength_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E::get_offset_of_useCameraFov_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t5F3D078AA124139ACFD469537C724B81EECAE64E::get_offset_of_kernelSize_4() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2923 = { sizeof (DitheringModel_t563302E6CCA426980051A9DD4BE43D907032077F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2923[1] = 
{
	DitheringModel_t563302E6CCA426980051A9DD4BE43D907032077F::get_offset_of_m_Settings_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2924 = { sizeof (Settings_tC9C0AEE3013633FFCEA5FDFD2D15E71EB7251724)+ sizeof (RuntimeObject), sizeof(Settings_tC9C0AEE3013633FFCEA5FDFD2D15E71EB7251724 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2925 = { sizeof (EyeAdaptationModel_t1ACCFD330F4AC0B18055B102CB33E568F6354255), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2925[1] = 
{
	EyeAdaptationModel_t1ACCFD330F4AC0B18055B102CB33E568F6354255::get_offset_of_m_Settings_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2926 = { sizeof (EyeAdaptationType_t4F58B587481FC6D1F5DD5A4775362728CEBBEBB5)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2926[3] = 
{
	EyeAdaptationType_t4F58B587481FC6D1F5DD5A4775362728CEBBEBB5::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2927 = { sizeof (Settings_t8A8457FAF6223DD887350322DC6D951891572426)+ sizeof (RuntimeObject), sizeof(Settings_t8A8457FAF6223DD887350322DC6D951891572426_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable2927[11] = 
{
	Settings_t8A8457FAF6223DD887350322DC6D951891572426::get_offset_of_lowPercent_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t8A8457FAF6223DD887350322DC6D951891572426::get_offset_of_highPercent_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t8A8457FAF6223DD887350322DC6D951891572426::get_offset_of_minLuminance_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t8A8457FAF6223DD887350322DC6D951891572426::get_offset_of_maxLuminance_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t8A8457FAF6223DD887350322DC6D951891572426::get_offset_of_keyValue_4() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t8A8457FAF6223DD887350322DC6D951891572426::get_offset_of_dynamicKeyValue_5() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t8A8457FAF6223DD887350322DC6D951891572426::get_offset_of_adaptationType_6() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t8A8457FAF6223DD887350322DC6D951891572426::get_offset_of_speedUp_7() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t8A8457FAF6223DD887350322DC6D951891572426::get_offset_of_speedDown_8() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t8A8457FAF6223DD887350322DC6D951891572426::get_offset_of_logMin_9() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t8A8457FAF6223DD887350322DC6D951891572426::get_offset_of_logMax_10() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2928 = { sizeof (FogModel_tCFF533017C35BAD8A878AC1912F1545DA5D1958B), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2928[1] = 
{
	FogModel_tCFF533017C35BAD8A878AC1912F1545DA5D1958B::get_offset_of_m_Settings_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2929 = { sizeof (Settings_tA824AD6B5D555CEB742A622222775333124B2107)+ sizeof (RuntimeObject), sizeof(Settings_tA824AD6B5D555CEB742A622222775333124B2107_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable2929[1] = 
{
	Settings_tA824AD6B5D555CEB742A622222775333124B2107::get_offset_of_excludeSkybox_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2930 = { sizeof (GrainModel_t9E9F9606895937388BD98DDBD0C12D33D820517A), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2930[1] = 
{
	GrainModel_t9E9F9606895937388BD98DDBD0C12D33D820517A::get_offset_of_m_Settings_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2931 = { sizeof (Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F)+ sizeof (RuntimeObject), sizeof(Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable2931[4] = 
{
	Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F::get_offset_of_colored_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F::get_offset_of_intensity_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F::get_offset_of_size_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_tCFBBF182482600D1B65A7B66A6B980BDE79A4D6F::get_offset_of_luminanceContribution_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2932 = { sizeof (MotionBlurModel_tF9261A288A5BDE37488E0D6F1EBF060FB528BCC3), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2932[1] = 
{
	MotionBlurModel_tF9261A288A5BDE37488E0D6F1EBF060FB528BCC3::get_offset_of_m_Settings_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2933 = { sizeof (Settings_t6272550371AE697276AC2B9E97B10C20531B4A02)+ sizeof (RuntimeObject), sizeof(Settings_t6272550371AE697276AC2B9E97B10C20531B4A02 ), 0, 0 };
extern const int32_t g_FieldOffsetTable2933[3] = 
{
	Settings_t6272550371AE697276AC2B9E97B10C20531B4A02::get_offset_of_shutterAngle_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t6272550371AE697276AC2B9E97B10C20531B4A02::get_offset_of_sampleCount_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t6272550371AE697276AC2B9E97B10C20531B4A02::get_offset_of_frameBlending_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2934 = { sizeof (ScreenSpaceReflectionModel_t05FF878FC8651BE6F59BC62D0167970B047A0A82), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2934[1] = 
{
	ScreenSpaceReflectionModel_t05FF878FC8651BE6F59BC62D0167970B047A0A82::get_offset_of_m_Settings_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2935 = { sizeof (SSRResolution_t40118FB40978EC7A537F3DF56576259886E87CA7)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2935[3] = 
{
	SSRResolution_t40118FB40978EC7A537F3DF56576259886E87CA7::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2936 = { sizeof (SSRReflectionBlendType_t11182016FBBAAEA4C9480BB658E7563133E34AF9)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2936[3] = 
{
	SSRReflectionBlendType_t11182016FBBAAEA4C9480BB658E7563133E34AF9::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2937 = { sizeof (IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087)+ sizeof (RuntimeObject), sizeof(IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087 ), 0, 0 };
extern const int32_t g_FieldOffsetTable2937[4] = 
{
	IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087::get_offset_of_reflectionMultiplier_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087::get_offset_of_fadeDistance_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087::get_offset_of_fresnelFade_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	IntensitySettings_tBF0EB1716740BB43A3A2E99806F9BC18D65DB087::get_offset_of_fresnelFadePower_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2938 = { sizeof (ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C)+ sizeof (RuntimeObject), sizeof(ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable2938[8] = 
{
	ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C::get_offset_of_blendType_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C::get_offset_of_reflectionQuality_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C::get_offset_of_maxDistance_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C::get_offset_of_iterationCount_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
	ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C::get_offset_of_stepSize_4() + static_cast<int32_t>(sizeof(RuntimeObject)),
	ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C::get_offset_of_widthModifier_5() + static_cast<int32_t>(sizeof(RuntimeObject)),
	ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C::get_offset_of_reflectionBlur_6() + static_cast<int32_t>(sizeof(RuntimeObject)),
	ReflectionSettings_t0E6A92FF17732807EDA06E014001FF6F5A65DC4C::get_offset_of_reflectBackfaces_7() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2939 = { sizeof (ScreenEdgeMask_t94FB1CC384B7C414838A714400DF33EE0F26C468)+ sizeof (RuntimeObject), sizeof(ScreenEdgeMask_t94FB1CC384B7C414838A714400DF33EE0F26C468 ), 0, 0 };
extern const int32_t g_FieldOffsetTable2939[1] = 
{
	ScreenEdgeMask_t94FB1CC384B7C414838A714400DF33EE0F26C468::get_offset_of_intensity_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2940 = { sizeof (Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4)+ sizeof (RuntimeObject), sizeof(Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4_marshaled_pinvoke), 0, 0 };
extern const int32_t g_FieldOffsetTable2940[3] = 
{
	Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4::get_offset_of_reflection_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4::get_offset_of_intensity_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_tEF3B42DA82D32321AD3A9E59B8BB1C0D1D2608A4::get_offset_of_screenEdgeMask_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2941 = { sizeof (UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2941[1] = 
{
	UserLutModel_t99960CD2432509AEAEF58A93BF15F710627939E3::get_offset_of_m_Settings_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2942 = { sizeof (Settings_t89579C94217BC0734AF7DE292787FC983E2B4313)+ sizeof (RuntimeObject), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2942[2] = 
{
	Settings_t89579C94217BC0734AF7DE292787FC983E2B4313::get_offset_of_lut_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t89579C94217BC0734AF7DE292787FC983E2B4313::get_offset_of_contribution_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2943 = { sizeof (VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2943[1] = 
{
	VignetteModel_t9F560B811D67D63F69CCF9336093DBAA7A62A968::get_offset_of_m_Settings_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2944 = { sizeof (Mode_t78BB10CCA9904C7105408E016CBC0AF7585A625D)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
extern const int32_t g_FieldOffsetTable2944[3] = 
{
	Mode_t78BB10CCA9904C7105408E016CBC0AF7585A625D::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2945 = { sizeof (Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C)+ sizeof (RuntimeObject), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2945[9] = 
{
	Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C::get_offset_of_mode_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C::get_offset_of_color_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C::get_offset_of_center_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C::get_offset_of_intensity_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C::get_offset_of_smoothness_4() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C::get_offset_of_roundness_5() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C::get_offset_of_mask_6() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C::get_offset_of_opacity_7() + static_cast<int32_t>(sizeof(RuntimeObject)),
	Settings_t38E3144318C540D0811780C3FC3CF5BFE3DF9A8C::get_offset_of_rounded_8() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2946 = { sizeof (PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2946[29] = 
{
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_profile_4(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_jitteredMatrixFunc_5(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_CommandBuffers_6(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_Components_7(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_ComponentStates_8(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_MaterialFactory_9(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_RenderTextureFactory_10(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_Context_11(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_Camera_12(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_PreviousProfile_13(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_RenderingInSceneView_14(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_DebugViews_15(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_AmbientOcclusion_16(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_ScreenSpaceReflection_17(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_FogComponent_18(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_MotionBlur_19(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_Taa_20(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_EyeAdaptation_21(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_DepthOfField_22(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_Bloom_23(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_ChromaticAberration_24(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_ColorGrading_25(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_UserLut_26(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_Grain_27(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_Vignette_28(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_Dithering_29(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_Fxaa_30(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_ComponentsToEnable_31(),
	PostProcessingBehaviour_t845414E0C0D9C84A787F25EB881C1D8990CC1469::get_offset_of_m_ComponentsToDisable_32(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2947 = { sizeof (PostProcessingComponentBase_tC8BC68DB18D717E17089935C74F230467E0BC942), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2947[1] = 
{
	PostProcessingComponentBase_tC8BC68DB18D717E17089935C74F230467E0BC942::get_offset_of_context_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2948 = { 0, 0, 0, 0 };
extern const int32_t g_FieldOffsetTable2948[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2949 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2950 = { 0, 0, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2951 = { sizeof (PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2951[5] = 
{
	PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7::get_offset_of_profile_0(),
	PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7::get_offset_of_camera_1(),
	PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7::get_offset_of_materialFactory_2(),
	PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7::get_offset_of_renderTextureFactory_3(),
	PostProcessingContext_tD8A98E2DAB2DEE2AFC721C88C293E14FE67A00E7::get_offset_of_U3CinterruptedU3Ek__BackingField_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2952 = { sizeof (PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2952[1] = 
{
	PostProcessingModel_tC42719DAEEB6DB4F6BB510983EA10BBFD3062E3A::get_offset_of_m_Enabled_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2953 = { sizeof (PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2953[15] = 
{
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_debugViews_4(),
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_fog_5(),
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_antialiasing_6(),
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_ambientOcclusion_7(),
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_screenSpaceReflection_8(),
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_depthOfField_9(),
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_motionBlur_10(),
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_eyeAdaptation_11(),
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_bloom_12(),
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_colorGrading_13(),
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_userLut_14(),
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_chromaticAberration_15(),
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_grain_16(),
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_vignette_17(),
	PostProcessingProfile_tDDAC51472A60B9B12D350E7635B49687A06A327F::get_offset_of_dithering_18(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2954 = { sizeof (ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2954[5] = 
{
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D::get_offset_of_curve_0(),
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D::get_offset_of_m_Loop_1(),
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D::get_offset_of_m_ZeroValue_2(),
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D::get_offset_of_m_Range_3(),
	ColorGradingCurve_tBB0E6A0AF584D1CDAEEFC1014CE35D0E426BEE9D::get_offset_of_m_InternalLoopingCurve_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2955 = { sizeof (GraphicsUtils_t158EBC195D948DBB2232E769FCC62C706A60F464), -1, sizeof(GraphicsUtils_t158EBC195D948DBB2232E769FCC62C706A60F464_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2955[2] = 
{
	GraphicsUtils_t158EBC195D948DBB2232E769FCC62C706A60F464_StaticFields::get_offset_of_s_WhiteTexture_0(),
	GraphicsUtils_t158EBC195D948DBB2232E769FCC62C706A60F464_StaticFields::get_offset_of_s_Quad_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2956 = { sizeof (MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2956[1] = 
{
	MaterialFactory_tBEC3A9AE4401BDF1E5645C87895C3BC097638F05::get_offset_of_m_Materials_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2957 = { sizeof (RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236), -1, 0, 0 };
extern const int32_t g_FieldOffsetTable2957[1] = 
{
	RenderTextureFactory_t522EDCAD4499B0594A69BCB40DB5698647DDB236::get_offset_of_m_TemporaryRTs_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2958 = { sizeof (U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A), -1, sizeof(U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_StaticFields), 0 };
extern const int32_t g_FieldOffsetTable2958[2] = 
{
	U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_StaticFields::get_offset_of_U351A7A390CD6DE245186881400B18C9D822EFE240_0(),
	U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_StaticFields::get_offset_of_C90F38A020811481753795774EB5AF353F414C59_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2959 = { sizeof (__StaticArrayInitTypeSizeU3D12_t65235398342E0C6C387633EE4B2E7F326A539C91)+ sizeof (RuntimeObject), sizeof(__StaticArrayInitTypeSizeU3D12_t65235398342E0C6C387633EE4B2E7F326A539C91 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize2960 = { sizeof (__StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34)+ sizeof (RuntimeObject), sizeof(__StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34 ), 0, 0 };
#ifdef __clang__
#pragma clang diagnostic pop
#endif
